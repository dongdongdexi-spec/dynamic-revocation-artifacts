# Supporting evidence

Paths in this archive use portable ASCII names. Reopen the outer archive index to locate evidence from other study phases. Some historical source scripts refer to the study tree used when the results were recorded.

## Documents and data

- [record-028309645e74/model-provenance/model-provenance.md](record-028309645e74/model-provenance/model-provenance.md)
- [record-028309645e74/record-f4834dea4b9d/related_work_patch.md](record-028309645e74/record-f4834dea4b9d/related_work_patch.md)
- [record-028309645e74/supplemental-notes/experimental_supplement.md](record-028309645e74/supplemental-notes/experimental_supplement.md)
- [record-028309645e74/tcp-fault/audit_ieee_joint_recovery.py](record-028309645e74/tcp-fault/audit_ieee_joint_recovery.py)
- [record-028309645e74/tcp-fault/audit_ieee_joint_recovery_tcp.py](record-028309645e74/tcp-fault/audit_ieee_joint_recovery_tcp.py)
- [record-028309645e74/tcp-fault/campaign.ipc.original.json](record-028309645e74/tcp-fault/campaign.ipc.original.json)
- [record-028309645e74/tcp-fault/campaign.json](record-028309645e74/tcp-fault/campaign.json)
- [record-028309645e74/tcp-fault/controls.csv](record-028309645e74/tcp-fault/controls.csv)
- [record-028309645e74/tcp-fault/gateway_events.csv](record-028309645e74/tcp-fault/gateway_events.csv)
- [record-028309645e74/tcp-fault/ieee_joint_recovery.py](record-028309645e74/tcp-fault/ieee_joint_recovery.py)
- [record-028309645e74/tcp-fault/ieee_joint_recovery_tcp.py](record-028309645e74/tcp-fault/ieee_joint_recovery_tcp.py)
- [record-028309645e74/tcp-fault/ieee_race_receipts.py](record-028309645e74/tcp-fault/ieee_race_receipts.py)
- [record-028309645e74/tcp-fault/ieee_scope_locks.py](record-028309645e74/tcp-fault/ieee_scope_locks.py)
- [record-028309645e74/tcp-fault/manifest.json](record-028309645e74/tcp-fault/manifest.json)
- [record-028309645e74/tcp-fault/protocol.ipc.original.json](record-028309645e74/tcp-fault/protocol.ipc.original.json)
- [record-028309645e74/tcp-fault/protocol.json](record-028309645e74/tcp-fault/protocol.json)
- [record-028309645e74/tcp-fault/receipts.sqlite](record-028309645e74/tcp-fault/receipts.sqlite)
- [record-028309645e74/tcp-fault/receiver_events.csv](record-028309645e74/tcp-fault/receiver_events.csv)
- [record-028309645e74/tcp-fault/receiver_events.json](record-028309645e74/tcp-fault/receiver_events.json)
- [record-028309645e74/tcp-fault/recipient_tcp_peers.json](record-028309645e74/tcp-fault/recipient_tcp_peers.json)
- [record-028309645e74/tcp-fault/record-37a233d5ce6a.md](record-028309645e74/tcp-fault/record-37a233d5ce6a.md)
- [record-028309645e74/tcp-fault/record-c7ceb961390f.json](record-028309645e74/tcp-fault/record-c7ceb961390f.json)
- [record-028309645e74/tcp-fault/requests.csv](record-028309645e74/tcp-fault/requests.csv)
- [record-028309645e74/tcp-fault/result.ipc.original.json](record-028309645e74/tcp-fault/result.ipc.original.json)
- [record-028309645e74/tcp-fault/result.json](record-028309645e74/tcp-fault/result.json)