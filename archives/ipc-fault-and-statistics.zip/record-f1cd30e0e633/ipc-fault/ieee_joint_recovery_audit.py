"""Independent audit of the confirmatory opaque-handle experiment."""

import argparse
import csv
import hashlib
import json
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path


FIELDS = ('epoch', 'id', 'recipient', 'scope', 'sha256')
EXPECTED_WIRE = ';'.join(sorted((*FIELDS, 'handle')))
COMMITTED_EVENTS = ('committed', 'committed_malformed_ack')
FENCE_EVENTS = ('precommit_fenced', 'fence_persisted')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_rows(path):
    with path.open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))


def group(rows, field):
    buckets = defaultdict(list)
    for row in rows:
        buckets[row[field]].append(row)
    return buckets


def per_attempt(rows):
    result = {(r['id'], int(r['attempt'])): r for r in rows}
    assert len(result) == len(rows)
    return result


def time_ns(row):
    return int(row['t_ns'])


def audit(root):
    protocol = read_json(root / 'protocol.json')
    config = read_json(root / 'campaign.json')
    manifest = read_json(root / 'manifest.json')
    gateway = group(read_rows(root / 'gateway_events.csv'), 'event')
    receiver = group(read_rows(root / 'receiver_events.csv'), 'event')
    requests = read_rows(root / 'requests.csv')
    control_calls = {row['action']: row for row in read_rows(root / 'controls.csv')}
    with sqlite3.connect((root / 'receipts.sqlite').resolve().as_uri() + '?mode=ro', uri=True) as db:
        assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        sql_rows = db.execute('SELECT id, scope, epoch, recipient, sha256, body, attempt, inserted_ns FROM receipts').fetchall()
        operations = db.execute('SELECT id, scope, epoch, recipient, sha256 FROM operations').fetchall()
        fences = db.execute('SELECT id, attempt, state FROM attempts').fetchall()

    assert not config['smoke'] and config['seed'] == protocol['seed'] and config['items'] == protocol['jobs_per_worker']
    assert config['transport'] == 'inherited_multiprocessing_pipe'
    assert Counter(r['workers'] for r in config['runs']) == {n: protocol['rounds_per_worker_count'] for n in protocol['worker_counts']}
    assert tuple(config['scenarios']) == tuple(protocol['fault_rotation'])
    assert len({row['id'] for row in manifest}) == len(manifest)
    issued = {row['id']: row for row in manifest}
    natural = {row['id']: row for row in manifest if row['stage'] == 'natural'}
    assert len({row['handle_sha256'] for row in manifest}) == len(manifest)

    schedules = {row['epoch']: row for row in config['runs']}
    for row in config['runs']:
        assert len(set(row['worker_pids'])) == row['workers']
        assert not {config['receiver_pid'], config['gateway_pid']}.intersection(row['worker_pids'])
        observed = {int(r['worker_pid']) for r in requests if int(r['epoch']) == row['epoch']}
        assert observed == set(row['worker_pids'])
    assert config['gateway_pid'] != config['receiver_pid']
    firsts = Counter(row['id'] for row in requests if row['action'] == 'first_submission')
    assert firsts == Counter(natural.keys())
    assert all(row['id'] in natural for row in requests)
    unbound_requests = 0
    for row in requests:
        original = natural[row['id']]
        assert int(row['worker_pid']) == schedules[original['epoch']]['worker_pids'][original['worker']]
        unbound_requests += any(row[field] != str(original[field]) for field in (*FIELDS, 'handle_sha256')) or row['wire_item_fields'] != EXPECTED_WIRE

    by_receipt = {row[0]: row for row in sql_rows}
    by_commit_event = group(receiver['committed'] + receiver['committed_malformed_ack'], 'id')
    seen_duplicates = len(sql_rows) - len(by_receipt) + sum(len(rows) - 1 for rows in by_commit_event.values())
    assert set(by_receipt) == set(by_commit_event)
    assert all((scope, epoch, recipient, digest) == (issued[op]['scope'], issued[op]['epoch'], issued[op]['recipient'], issued[op]['sha256'])
               for op, scope, epoch, recipient, digest in operations)
    digest_mismatches = 0
    for op, scope, epoch, recipient, expected, body, attempt, inserted in sql_rows:
        logged = by_commit_event[op][0]
        original = issued[op]
        digest_mismatches += hashlib.sha256(body.encode()).hexdigest() != expected or expected != original['sha256']
        assert (scope, epoch, recipient) == (original['scope'], original['epoch'], original['recipient'])
        assert (logged['scope'], int(logged['epoch']), int(logged['attempt'])) == (scope, epoch, attempt)
        assert time_ns(logged) >= inserted

    fence_records = per_attempt(receiver['precommit_fenced'] + receiver['fence_persisted'])
    assert all(state == 'fenced' for _, _, state in fences)
    assert set(fence_records) == {(op, attempt) for op, attempt, _ in fences}
    grants = {(row['scope'], int(row['epoch'])): time_ns(row) for row in gateway['grant']}
    publications = {int(row['epoch']): time_ns(row) for row in gateway['revoke_published']}
    revoke_requests = {int(row['epoch']): time_ns(row) for row in gateway['revoke_requested']}
    assert publications.keys() == revoke_requests.keys() == schedules.keys()
    assert all(grants['withdrawn', k] <= revoke_requests[k] <= publications[k] for k in schedules)

    authorized = per_attempt(gateway['authorized'])
    decrypted = per_attempt(gateway['decrypt_under_lease'])
    terminal_leases = per_attempt(gateway['lease_terminal'])
    assert authorized.keys() == decrypted.keys()
    late_closures = 0
    earlier_cleanup = 0
    missing_terminal = len(authorized.keys() - terminal_leases.keys())
    for attempt_key, admitted in authorized.items():
        op, attempt = attempt_key
        assert time_ns(decrypted[attempt_key]) <= time_ns(admitted)
        terminal = terminal_leases.get(attempt_key)
        if terminal is not None:
            durable = (by_commit_event[op][0] if terminal['state'] == 'committed' and op in by_commit_event
                       else fence_records.get(attempt_key) if terminal['state'] == 'fenced' else None)
            if durable is None or int(durable['attempt']) != attempt or not time_ns(admitted) <= time_ns(durable) <= time_ns(terminal):
                missing_terminal += 1
            if admitted['scope'] == 'withdrawn' and int(admitted['epoch']) in publications:
                late_closures += time_ns(terminal) >= publications[int(admitted['epoch'])]
        if attempt > 1:
            fence = fence_records.get((op, attempt - 1))
            if fence is None or time_ns(admitted) < time_ns(fence):
                earlier_cleanup += 1
    assert not (terminal_leases.keys() - authorized.keys())
    assert late_closures == 0 and earlier_cleanup == 0

    natural_settled = {row['id']: row for row in gateway['settled'] if row['id'] in natural}
    assert len(natural_settled) == sum(row['id'] in natural for row in gateway['settled'])
    nonterminal = sum(op not in natural_settled or natural_settled[op]['state'] not in ('denied', 'committed') for op in natural)
    assert all((op in by_receipt) == (row['state'] == 'committed') for op, row in natural_settled.items())
    independent_deliveries = sum(issued[op]['scope'] == 'independent' for op in natural.keys() & by_receipt.keys())
    withdrawn_commit_rows = [rows[0] for op, rows in by_commit_event.items() if op in natural and issued[op]['scope'] == 'withdrawn']
    after_publication = sum(time_ns(row) >= publications[int(row['epoch'])] for row in withdrawn_commit_rows)
    during_revoke = sum(revoke_requests[int(row['epoch'])] <= time_ns(row) < publications[int(row['epoch'])] for row in withdrawn_commit_rows)
    wrong_open = sum(row['scope'] == 'withdrawn' and int(row['epoch']) in publications and time_ns(row) >= publications[int(row['epoch'])]
                     for row in gateway['decrypt_under_lease'])
    overlap_epochs = {int(row['epoch']) for key_, row in authorized.items() if row['scope'] == 'withdrawn' and key_ in terminal_leases
                      and int(row['epoch']) in revoke_requests
                      and time_ns(row) <= revoke_requests[int(row['epoch'])] < time_ns(terminal_leases[key_])}
    resolved = per_attempt(gateway['receipt_resolved'])
    rejected = per_attempt(gateway['unbound_reply_rejected'])
    malformed = per_attempt(receiver['committed_malformed_ack'])
    fixed_malformed = sum(k in resolved and k in rejected and resolved[k]['state'] == 'committed'
                          and time_ns(r) <= time_ns(rejected[k]) <= time_ns(resolved[k]) for k, r in malformed.items())
    for row in receiver['fenced_original_refused']:
        assert time_ns(row) >= time_ns(fence_records[row['id'], int(row['attempt'])])

    control_outcomes = {name: row['status'] for name, row in control_calls.items()}
    assert by_receipt.keys() - natural.keys() == {'regrant-control'}
    assert len([r for r in gateway['decrypt_under_lease'] if r['id'] == 'regrant-control']) == 1
    assert not any(r['id'] in ('retired-control', 'invalid-tag-control') for r in gateway['decrypt_under_lease'])
    assert publications[1] < grants['withdrawn', len(config['runs']) + 1]
    measurements = {
        'issued_natural_operations': len(natural),
        'independent_deliveries': independent_deliveries,
        'post_publication_old_commits': after_publication,
        'post_publication_old_decrypt_admissions': wrong_open,
        'duplicate_durable_receipts': seen_duplicates,
        'digest_mismatches': digest_mismatches,
        'unbound_worker_requests_in_natural_runs': unbound_requests,
        'missing_or_nonterminal_natural_operations': nonterminal,
        'authorized_attempts_without_matching_durable_receipt_or_fence_before_lease_release': missing_terminal,
        'retired_scope_overlap_rounds_minimum': len(overlap_epochs),
        'target_scope_actual_ack_suppression_minimum': sum(row['scope'] == 'withdrawn' for row in receiver['ack_suppressed']),
        'target_scope_durable_fence_minimum': sum(row['scope'] == 'withdrawn' for row in fence_records.values()),
        'target_scope_attempt_denials_minimum': sum(row['id'] in natural for row in gateway['denied']),
        'delayed_original_refusals_minimum': len(receiver['fenced_original_refused']),
        'cached_duplicate_outcomes_minimum': sum(row['id'] in natural for row in gateway['duplicate_returned_cached_status']),
        'malformed_ack_rejected_and_resolved_minimum': fixed_malformed,
    }
    thresholds = protocol['primary_gates']
    gate = {k: measurements[k] >= v if k.endswith('_minimum') else measurements[k] == v for k, v in thresholds.items()}
    supports = all(gate.values()) and control_outcomes == protocol['secondary_controls']
    return {'supports_mainline': supports, 'primary_gate_results': gate, 'measured': measurements,
            'secondary_controls': control_outcomes, 'seed': config['seed'],
            'rounds': len(config['runs']), 'calls': len(requests), 'transport': config['transport'],
            'natural_receipts': len(natural.keys() & by_receipt.keys()), 'withdrawn_scope_pre_publication_commits': len(withdrawn_commit_rows),
            'withdrawn_scope_between_request_and_publication': during_revoke,
            'withdrawn_scope_pre_request_commits': len(withdrawn_commit_rows) - during_revoke - after_publication,
            'naturally_denied_operations': sum(row['state'] == 'denied' for row in natural_settled.values()),
            'recovery_candidates': len(gateway['uncertain']), 'all_ack_suppressions': len(receiver['ack_suppressed']),
            'all_durable_fences': len(fence_records), 'all_malformed_ack_injections': len(malformed),
            'natural_authorized_attempts': sum(k[0] in natural for k in authorized),
            'natural_authorized_retry_attempts': sum(op in natural and attempt > 1 for op, attempt in authorized),
            'natural_denied_retry_attempts': sum(row['id'] in natural and int(row['attempt']) > 1 for row in gateway['denied'])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    args = parser.parse_args()
    summary = audit(args.input)
    (args.input / 'result.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))
    if not summary['supports_mainline']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
