# Supporting evidence

Paths in this archive use portable ASCII names. Reopen the outer archive index to locate evidence from other study phases. Some historical source scripts refer to the study tree used when the results were recorded.

## Documents and data

- [record-f1cd30e0e633/ipc-fault/audit_ieee_joint_recovery.py](record-f1cd30e0e633/ipc-fault/audit_ieee_joint_recovery.py)
- [record-f1cd30e0e633/ipc-fault/campaign.json](record-f1cd30e0e633/ipc-fault/campaign.json)
- [record-f1cd30e0e633/ipc-fault/controls.csv](record-f1cd30e0e633/ipc-fault/controls.csv)
- [record-f1cd30e0e633/ipc-fault/gateway_events.csv](record-f1cd30e0e633/ipc-fault/gateway_events.csv)
- [record-f1cd30e0e633/ipc-fault/ieee_joint_recovery.py](record-f1cd30e0e633/ipc-fault/ieee_joint_recovery.py)
- [record-f1cd30e0e633/ipc-fault/ieee_joint_recovery_audit.py](record-f1cd30e0e633/ipc-fault/ieee_joint_recovery_audit.py)
- [record-f1cd30e0e633/ipc-fault/ieee_race_receipts.py](record-f1cd30e0e633/ipc-fault/ieee_race_receipts.py)
- [record-f1cd30e0e633/ipc-fault/ieee_scope_locks.py](record-f1cd30e0e633/ipc-fault/ieee_scope_locks.py)
- [record-f1cd30e0e633/ipc-fault/manifest.json](record-f1cd30e0e633/ipc-fault/manifest.json)
- [record-f1cd30e0e633/ipc-fault/protocol.json](record-f1cd30e0e633/ipc-fault/protocol.json)
- [record-f1cd30e0e633/ipc-fault/receipts.sqlite](record-f1cd30e0e633/ipc-fault/receipts.sqlite)
- [record-f1cd30e0e633/ipc-fault/receiver_events.csv](record-f1cd30e0e633/ipc-fault/receiver_events.csv)
- [record-f1cd30e0e633/ipc-fault/receiver_events.json](record-f1cd30e0e633/ipc-fault/receiver_events.json)
- [record-f1cd30e0e633/ipc-fault/record-7137727d153c.json](record-f1cd30e0e633/ipc-fault/record-7137727d153c.json)
- [record-f1cd30e0e633/ipc-fault/record-e70822ac2930.md](record-f1cd30e0e633/ipc-fault/record-e70822ac2930.md)
- [record-f1cd30e0e633/ipc-fault/requests.csv](record-f1cd30e0e633/ipc-fault/requests.csv)
- [record-f1cd30e0e633/ipc-fault/result.json](record-f1cd30e0e633/ipc-fault/result.json)
- [record-f1cd30e0e633/paired-statistics/ieee_review_paired_rounds.py](record-f1cd30e0e633/paired-statistics/ieee_review_paired_rounds.py)
- [record-f1cd30e0e633/paired-statistics/record-670f5183828e.csv.gz](record-f1cd30e0e633/paired-statistics/record-670f5183828e.csv.gz)
- [record-f1cd30e0e633/paired-statistics/record-6799526e50a9.json](record-f1cd30e0e633/paired-statistics/record-6799526e50a9.json)
- [record-f1cd30e0e633/paired-statistics/record-b9270409ccc2.md](record-f1cd30e0e633/paired-statistics/record-b9270409ccc2.md)
- [record-f1cd30e0e633/paired-statistics/record-f4bcbbe3bd7b.csv](record-f1cd30e0e633/paired-statistics/record-f4bcbbe3bd7b.csv)
- [record-f1cd30e0e633/record-fe1325d2ad9f.md](record-f1cd30e0e633/record-fe1325d2ad9f.md)