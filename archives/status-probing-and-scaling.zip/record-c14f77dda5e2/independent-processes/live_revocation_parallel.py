"""Measure a centralized revocation fence with actual loopback worker processes."""

import argparse
import csv
import gzip
import json
import multiprocessing as mp
import os
import platform
import random
import socket
import socketserver
import struct
import threading
import time
from pathlib import Path


NOW = time.perf_counter_ns
WORKERS = (1, 6, 16, 32, 64)
HELLO = struct.Struct('!H')
REPLY = struct.Struct('!IBQQ')
STOP_ROUND = 0xFFFFFFFF
RAW_FIELDS = ('workers', 'worker', 'pid', 'round', 'route', 'allowed', 'revoked_at_gate',
              'send_ns', 'admitted_ns', 'received_ns', 'gateway_ns')


def read_exact(sock, size):
    chunks = bytearray()
    while len(chunks) < size:
        part = sock.recv(size - len(chunks))
        if not part:
            raise EOFError('peer closed a partial message')
        chunks.extend(part)
    return bytes(chunks)


class Gate:
    def __init__(self):
        self.lock = threading.Lock()
        self.slots = {'independent': os.urandom(32)}
        self.round = 0
        self.stopping = False

    def reset(self, round_id):
        key = os.urandom(32)
        with self.lock:
            self.round = round_id
            self.slots['old'] = key

    def revoke(self):
        called = NOW()
        with self.lock:
            acquired = NOW()
            self.slots.pop('old')
            committed = NOW()
        returned = NOW()
        return called, acquired, committed, returned

    def authorize(self, route):
        started = NOW()
        with self.lock:
            revoked = 'old' not in self.slots
            allowed = route in self.slots
            round_id = STOP_ROUND if self.stopping else self.round
            admitted = NOW()
        return round_id, int(allowed) | (int(revoked) << 1), admitted, admitted - started

    def stop(self):
        with self.lock:
            self.stopping = True


class ProbeServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    request_queue_size = 128

    def __init__(self, count):
        self.gate = Gate()
        self.condition = threading.Condition()
        self.start = threading.Event()
        self.registrations = set()
        self.progress = {}
        self.errors = []
        self.count = count
        super().__init__(('127.0.0.1', 0), ProbeHandler)

    def register(self, worker):
        with self.condition:
            if worker not in range(self.count) or worker in self.registrations:
                raise ValueError(f'invalid registration {worker}')
            self.registrations.add(worker)
            self.condition.notify_all()

    def reached(self, round_id, worker, flag):
        with self.condition:
            reached = self.progress.setdefault((round_id, flag), set())
            reached.add(worker)
            if len(reached) == self.count:
                self.condition.notify_all()

    def wait(self, predicate, timeout, label):
        with self.condition:
            ready = self.condition.wait_for(lambda: predicate() or self.errors, timeout=timeout)
            if not ready or self.errors:
                raise RuntimeError(f'{label}: {self.errors or "timeout"}')

    def all_at(self, round_id, flag):
        return len(self.progress.get((round_id, flag), ())) == self.count


class ProbeHandler(socketserver.BaseRequestHandler):
    def handle(self):
        server = self.server
        sock = self.request
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.settimeout(40)
        try:
            worker, = HELLO.unpack(read_exact(sock, HELLO.size))
            server.register(worker)
            if not server.start.wait(35):
                raise TimeoutError('worker start')
            observed = set()
            while True:
                channel = read_exact(sock, 1)
                route = {b'O': 'old', b'I': 'independent'}[channel]
                decision = server.gate.authorize(route)
                sock.sendall(REPLY.pack(*decision))
                round_id, bits, _, _ = decision
                if round_id == STOP_ROUND:
                    return
                flag = ('old_allow' if bits & 1 else 'old_deny') if route == 'old' else (
                    'independent_after' if bits == 3 else None)
                if flag is not None and (round_id, flag) not in observed:
                    observed.add((round_id, flag))
                    server.reached(round_id, worker, flag)
        except (EOFError, OSError, KeyError, ValueError) as exc:
            if not server.gate.stopping:
                with server.condition:
                    server.errors.append(str(exc))
                    server.condition.notify_all()


def worker_main(address, count, worker, path, probe_delay_s):
    rows = []
    randomizer = random.Random(worker + count * 1337)
    with socket.create_connection(address, timeout=35) as sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.sendall(HELLO.pack(worker))
        index = 0
        while True:
            independent = index % 4 == worker % 4
            sent = NOW()
            sock.sendall(b'I' if independent else b'O')
            round_id, bits, admitted, gateway = REPLY.unpack(read_exact(sock, REPLY.size))
            received = NOW()
            if round_id == STOP_ROUND:
                break
            rows.append((count, worker, os.getpid(), round_id, 'independent' if independent else 'old',
                         int(bool(bits & 1)), int(bool(bits & 2)), sent, admitted, received, gateway))
            index += 1
            time.sleep(probe_delay_s * randomizer.uniform(0.8, 1.2))
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(RAW_FIELDS)
        writer.writerows(rows)


def run_scale(count, rounds, pre, post, probe, workdir):
    print(f'{count} workers: starting {rounds} rounds', flush=True)
    server = ProbeServer(count)
    serving = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.02}, daemon=True)
    serving.start()
    context = mp.get_context('spawn')
    children = []
    paths = []
    updates = []
    worker_dir = workdir / f'workers_{count:03}'
    worker_dir.mkdir(parents=True, exist_ok=True)
    try:
        for worker in range(count):
            path = worker_dir / f'{worker:03}.csv'
            proc = context.Process(target=worker_main,
                                   args=(server.server_address, count, worker, path, probe))
            proc.start()
            paths.append(path)
            children.append(proc)
        server.wait(lambda: len(server.registrations) == count, 30, 'registration')
        for round_id in range(1, rounds + 1):
            server.gate.reset(round_id)
            server.start.set()
            server.wait(lambda: server.all_at(round_id, 'old_allow'), 6, 'old authorization before revoke')
            time.sleep(pre)
            called, acquired, committed, returned = server.gate.revoke()
            server.wait(lambda: server.all_at(round_id, 'old_deny') and server.all_at(round_id, 'independent_after'),
                        6, 'post-revocation coverage')
            time.sleep(post)
            updates.append({'workers': count, 'round': round_id, 'called_ns': called, 'acquired_ns': acquired,
                            'committed_ns': committed, 'returned_ns': returned,
                            'slot_update_ns': committed - acquired, 'revoke_call_ns': returned - called})
    finally:
        server.gate.stop()
        server.start.set()
        deadline = time.monotonic() + 12
        for child in children:
            child.join(timeout=max(0, deadline - time.monotonic()))
        for child in children:
            if child.is_alive():
                child.terminate()
                child.join(timeout=2)
        server.shutdown()
        server.server_close()
        serving.join(timeout=2)
    failures = [(child.pid, child.exitcode) for child in children if child.exitcode != 0]
    if failures or server.errors:
        raise RuntimeError(f'worker failures: {failures}; server: {server.errors}')
    if len({child.pid for child in children}) != count:
        raise AssertionError('scale must use distinct worker processes')
    print(f'{count} workers: completed; PIDs={len(children)}', flush=True)
    return updates, paths


def percentile(values, fraction):
    data = sorted(values)
    pos = (len(data) - 1) * fraction
    lo = int(pos)
    hi = min(lo + 1, len(data) - 1)
    return data[lo] + (data[hi] - data[lo]) * (pos - lo)


def stats(values):
    return {'p50': percentile(values, .50), 'p95': percentile(values, .95), 'max': max(values)}


def score_scale(count, updates, probe_paths, raw_writer):
    by_round = {r['round']: r for r in updates}
    observations = {(r['round'], wid): {'old_allow': [], 'old_deny': [], 'independent_after': 0}
                    for r in updates for wid in range(count)}
    gate_ns, client_ns = [], []
    old_gate_ns = {'allow': [], 'deny': []}
    samples = 0
    old_allow_acknowledged_after_commit = 0
    for path in probe_paths:
        with path.open(encoding='utf-8', newline='') as stream:
            for src in csv.DictReader(stream):
                row = {k: (v if k == 'route' else int(v)) for k, v in src.items()}
                raw_writer.writerow(row)
                r = by_round[row['round']]
                obs = observations[row['round'], row['worker']]
                admitted, received, sent = (row[k] for k in ('admitted_ns', 'received_ns', 'send_ns'))
                if not sent <= admitted <= received:
                    raise AssertionError('inconsistent loopback timestamp order')
                after = admitted >= r['committed_ns']
                if after != bool(row['revoked_at_gate']):
                    raise AssertionError('gateway observation disagrees with epoch publication order')
                gate_ns.append(row['gateway_ns'])
                client_ns.append(received - sent)
                samples += 1
                if row['route'] == 'old':
                    if bool(row['allowed']) == after:
                        raise AssertionError('stale admission after the revocation fence, or a premature denial')
                    key = 'allow' if row['allowed'] else 'deny'
                    if row['allowed'] and received >= r['committed_ns']:
                        old_allow_acknowledged_after_commit += 1
                    old_gate_ns[key].append(row['gateway_ns'])
                    obs[f'old_{key}'].append((admitted, received, row['pid']))
                else:
                    if not row['allowed']:
                        raise AssertionError('independent permission changed')
                    if after:
                        obs['independent_after'] += 1
    workers = []
    for (trial, wid), obs in observations.items():
        commit = by_round[trial]['committed_ns']
        last_allow = max(obs['old_allow'], key=lambda x: x[0])
        first_deny = min(obs['old_deny'], key=lambda x: x[0])
        if last_allow[2] != first_deny[2] or obs['independent_after'] == 0:
            raise AssertionError('missing per-worker positive control or worker PID changed')
        workers.append({'workers': count, 'round': trial, 'worker': wid, 'pid': last_allow[2],
                        'last_old_accept_gate_ns': last_allow[0], 'last_old_accept_received_ns': last_allow[1],
                        'first_old_reject_gate_ns': first_deny[0], 'first_old_reject_received_ns': first_deny[1],
                        'last_old_accept_gate_before_revoke_ns': commit - last_allow[0],
                        'first_old_reject_gate_after_revoke_ns': first_deny[0] - commit,
                        'first_old_reject_observed_after_revoke_ns': first_deny[1] - commit,
                        'old_allowed_count': len(obs['old_allow']), 'old_denied_count': len(obs['old_deny']),
                        'independent_allowed_after_revoke_count': obs['independent_after']})
    for trial in updates:
        rows = [r for r in workers if r['round'] == trial['round']]
        assert len({r['pid'] for r in rows}) == count
        observed = [r['first_old_reject_observed_after_revoke_ns'] for r in rows]
        trial['slowest_gate_first_reject_ns'] = max(r['first_old_reject_gate_after_revoke_ns'] for r in rows)
        trial['slowest_observed_first_reject_ns'] = max(observed)
        trial['first_reject_observation_spread_ns'] = max(observed) - min(observed)
        trial['last_pre_revoke_accept_gap_ns'] = min(r['last_old_accept_gate_before_revoke_ns'] for r in rows)
    summary = {'workers': count, 'rounds': len(updates), 'requests': samples,
               'slot_update_ns': stats([row['slot_update_ns'] for row in updates]),
               'revoke_call_ns': stats([row['revoke_call_ns'] for row in updates]),
               'gateway_ns': stats(gate_ns), 'old_allowed_gateway_ns': stats(old_gate_ns['allow']),
               'old_denied_gateway_ns': stats(old_gate_ns['deny']), 'request_rtt_ns': stats(client_ns),
               'last_old_accept_before_revoke_ns': stats([r['last_old_accept_gate_before_revoke_ns'] for r in workers]),
               'first_reject_at_gate_ns': stats([r['first_old_reject_gate_after_revoke_ns'] for r in workers]),
               'first_reject_observed_ns': stats([r['first_old_reject_observed_after_revoke_ns'] for r in workers]),
               'slowest_gate_first_reject_ns': stats([r['slowest_gate_first_reject_ns'] for r in updates]),
               'slowest_observed_first_reject_ns': stats([r['slowest_observed_first_reject_ns'] for r in updates]),
               'first_reject_observation_spread_ns': stats([r['first_reject_observation_spread_ns'] for r in updates]),
               'old_accepted_after_revoke': 0,
               'old_allow_acknowledged_after_commit': old_allow_acknowledged_after_commit,
               'workers_rounds_independent_control_passed': len(workers)}
    return summary, workers


def csv_out(path, records):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=tuple(records[0]))
        w.writeheader()
        w.writerows(records)


def flatten(summary):
    return {f'{name}_{percent}': value for name, stat in summary.items() if isinstance(stat, dict)
            for percent, value in stat.items()} | {name: v for name, v in summary.items() if not isinstance(v, dict)}


def render(path, report):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11, 'axes.spines.top': False,
                         'axes.spines.right': False, 'svg.fonttype': 'none'})
    rows = report['scales']
    x = [r['workers'] for r in rows]
    fig, (gateway, endpoint) = plt.subplots(1, 2, figsize=(12.2, 5.5))
    fig.subplots_adjust(left=.085, right=.986, bottom=.30, top=.82, wspace=.245)
    fig.suptitle('Revocation with concurrent worker processes', fontsize=16, weight='bold', y=.96)

    def line(axis, key, label, color, divisor, style='-'):
        p50 = [r[key]['p50'] / divisor for r in rows]
        p95 = [r[key]['p95'] / divisor for r in rows]
        axis.plot(x, p50, 'o', linestyle=style, lw=2, color=color, label=label, markersize=5)
        axis.plot(x, p95, ':', lw=1.35, color=color)
        axis.fill_between(x, p50, p95, color=color, alpha=.10)

    line(gateway, 'slot_update_ns', 'Epoch slot update', '#176b75', 1_000)
    line(gateway, 'revoke_call_ns', 'Revocation call', '#203957', 1_000, '--')
    line(gateway, 'gateway_ns', 'Gateway authorization', '#a66321', 1_000)
    gateway.set(ylabel='Time (µs)', title='Central measurements')
    line(endpoint, 'slowest_observed_first_reject_ns', 'Slowest first rejection per round', '#203957', 1_000_000)
    line(endpoint, 'first_reject_observation_spread_ns', 'First rejection spread per round', '#176b75', 1_000_000, '--')
    line(endpoint, 'request_rtt_ns', 'Request round trip', '#a66321', 1_000_000)
    endpoint.set(ylabel='Time (ms)', title='Worker observations on loopback')
    for ax in (gateway, endpoint):
        ax.set_xscale('log', base=2)
        ax.set_xticks(x, [str(v) for v in x])
        ax.set_xlabel('Concurrent worker processes')
        ax.set_ylim(bottom=0)
        ax.grid(axis='y', alpha=.22)
        ax.legend(loc='upper left', bbox_to_anchor=(0, -.21), borderaxespad=0, frameon=False, fontsize=9)
    fig.text(.5, .035, 'Markers show the median. Dotted curves show p95. Workers probe on one host over TCP loopback.',
             ha='center', color='#4b5563', fontsize=9)
    fig.savefig(path / 'revocation_parallel.png', dpi=220)
    fig.savefig(path / 'revocation_parallel.svg')
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path(__file__).parent / 'live_revocation_parallel')
    parser.add_argument('--workers', type=int, nargs='+', default=WORKERS)
    parser.add_argument('--rounds', type=int, default=12)
    parser.add_argument('--probe-ms', type=float, default=2.5)
    parser.add_argument('--pre-ms', type=float, default=50)
    parser.add_argument('--post-ms', type=float, default=50)
    args = parser.parse_args()
    if not 0 < args.rounds or any(count <= 0 for count in args.workers) or len(set(args.workers)) != len(args.workers):
        parser.error('rounds and unique worker counts must be positive')
    args.out.mkdir(parents=True, exist_ok=True)
    summaries, worker_rows, rounds = [], [], []
    with gzip.open(args.out / 'probe_samples.csv.gz', 'wt', newline='', encoding='utf-8') as stream:
        raw = csv.DictWriter(stream, fieldnames=RAW_FIELDS)
        raw.writeheader()
        for count in args.workers:
            trial, probes = run_scale(count, args.rounds, args.pre_ms / 1_000,
                                      args.post_ms / 1_000, args.probe_ms / 1_000, args.out)
            summary, details = score_scale(count, trial, probes, raw)
            summaries.append(summary)
            worker_rows.extend(details)
            rounds.extend(trial)
    csv_out(args.out / 'summary.csv', [flatten(r) for r in summaries])
    csv_out(args.out / 'rounds.csv', rounds)
    csv_out(args.out / 'worker_rounds.csv', worker_rows)
    result = {'scope': 'Independent spawned Python processes probing one central in-memory grant index over TCP loopback.',
              'host': platform.platform(), 'python': platform.python_version(), 'cpu_count': os.cpu_count(),
              'rounds_per_scale': args.rounds, 'probe_interval_ms': args.probe_ms,
              'probe_jitter': 'uniform in [0.8, 1.2] times delay, per worker random seed determined by scale and id',
              'probe_mix': 'three protected scope calls per independent-scope control, closed-loop',
              'pre_revoke_extra_load_ms': args.pre_ms, 'post_cover_extra_load_ms': args.post_ms,
              'clock': 'perf_counter_ns; per request client send <= central admission <= client receive verified',
              'definitions': {'slot_update_ns': 'inside-lock old slot deletion through epoch publication timestamp',
                              'revoke_call_ns': 'revocation call including lock acquisition',
                              'gateway_ns': 'central authorization start through inside-lock decision timestamp, excluding TCP',
                              'request_rtt_ns': 'client send to full acknowledgment received on persistent TCP socket',
                              'first_reject_at_gate_ns': 'first sampled protected denial at gateway after epoch publication',
                              'first_reject_observed_ns': 'first sampled denial acknowledgment at worker after epoch publication',
                              'slowest_observed_first_reject_ns': 'per round, slowest first client denial across workers',
                              'first_reject_observation_spread_ns': 'per round, last minus first client denial across workers',
                              'old_allow_acknowledged_after_commit': 'status-only allow acknowledgments received after publication for calls already admitted before publication'},
              'scales': summaries}
    (args.out / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    render(args.out, result)
    print(f"Wrote {len(summaries)} scales, {len(rounds)} rounds, {sum(x['requests'] for x in summaries)} samples", flush=True)


if __name__ == '__main__':
    mp.freeze_support()
    main()
