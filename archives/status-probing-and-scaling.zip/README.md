# Supporting evidence

Paths in this archive use portable ASCII names. Reopen the outer archive index to locate evidence from other study phases. Some historical source scripts refer to the study tree used when the results were recorded.

## Documents and data

- [record-c14f77dda5e2/historical-scaling/record-1d9523701923.md](record-c14f77dda5e2/historical-scaling/record-1d9523701923.md)
- [record-c14f77dda5e2/historical-scaling/revocation_scaling.png](record-c14f77dda5e2/historical-scaling/revocation_scaling.png)
- [record-c14f77dda5e2/historical-scaling/revocation_scaling.svg](record-c14f77dda5e2/historical-scaling/revocation_scaling.svg)
- [record-c14f77dda5e2/historical-scaling/revocation_scaling_summary.csv](record-c14f77dda5e2/historical-scaling/revocation_scaling_summary.csv)
- [record-c14f77dda5e2/independent-processes/live_revocation_parallel.py](record-c14f77dda5e2/independent-processes/live_revocation_parallel.py)
- [record-c14f77dda5e2/independent-processes/probe_samples.csv.gz](record-c14f77dda5e2/independent-processes/probe_samples.csv.gz)
- [record-c14f77dda5e2/independent-processes/record-5e599ee1d46a.md](record-c14f77dda5e2/independent-processes/record-5e599ee1d46a.md)
- [record-c14f77dda5e2/independent-processes/record-f8eb2cb79322.json](record-c14f77dda5e2/independent-processes/record-f8eb2cb79322.json)
- [record-c14f77dda5e2/independent-processes/result.json](record-c14f77dda5e2/independent-processes/result.json)
- [record-c14f77dda5e2/independent-processes/revocation_parallel.png](record-c14f77dda5e2/independent-processes/revocation_parallel.png)
- [record-c14f77dda5e2/independent-processes/revocation_parallel.svg](record-c14f77dda5e2/independent-processes/revocation_parallel.svg)
- [record-c14f77dda5e2/independent-processes/rounds.csv](record-c14f77dda5e2/independent-processes/rounds.csv)
- [record-c14f77dda5e2/independent-processes/summary.csv](record-c14f77dda5e2/independent-processes/summary.csv)
- [record-c14f77dda5e2/independent-processes/worker_rounds.csv](record-c14f77dda5e2/independent-processes/worker_rounds.csv)