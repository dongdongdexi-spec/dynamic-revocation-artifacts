# Supporting evidence

Paths in this archive use portable ASCII names. Reopen the outer archive index to locate evidence from other study phases. Some historical source scripts refer to the study tree used when the results were recorded.

## Documents and data

- [record-72f1ba01f9ad/execution-traces.json](record-72f1ba01f9ad/execution-traces.json)
- [record-72f1ba01f9ad/five-arm-report.md](record-72f1ba01f9ad/five-arm-report.md)
- [record-72f1ba01f9ad/five-arm-results.json](record-72f1ba01f9ad/five-arm-results.json)
- [record-72f1ba01f9ad/formal60_five_report.py](record-72f1ba01f9ad/formal60_five_report.py)
- [record-72f1ba01f9ad/formal60_scoring.py](record-72f1ba01f9ad/formal60_scoring.py)
- [record-72f1ba01f9ad/frozen-cases.json](record-72f1ba01f9ad/frozen-cases.json)
- [record-72f1ba01f9ad/frozen-conditions.json](record-72f1ba01f9ad/frozen-conditions.json)
- [record-72f1ba01f9ad/frozen-rules.json](record-72f1ba01f9ad/frozen-rules.json)
- [record-72f1ba01f9ad/record-deaec031847b.json](record-72f1ba01f9ad/record-deaec031847b.json)