# Supporting evidence

Paths in this archive use portable ASCII names. Reopen the outer archive index to locate evidence from other study phases. Some historical source scripts refer to the study tree used when the results were recorded.

## Documents and data

- [record-74390e94f8df/historical-scaling/revocation_scaling.png](record-74390e94f8df/historical-scaling/revocation_scaling.png)
- [record-74390e94f8df/historical-scaling/revocation_scaling.svg](record-74390e94f8df/historical-scaling/revocation_scaling.svg)
- [record-74390e94f8df/historical-scaling/revocation_scaling_summary.csv](record-74390e94f8df/historical-scaling/revocation_scaling_summary.csv)
- [record-74390e94f8df/record-c28895c237c8/record-384b037f2d55.json](record-74390e94f8df/record-c28895c237c8/record-384b037f2d55.json)
- [record-74390e94f8df/record-c28895c237c8/record-6d5c568641c3.json](record-74390e94f8df/record-c28895c237c8/record-6d5c568641c3.json)
- [record-74390e94f8df/record-c28895c237c8/record-ad98ac505def.json](record-74390e94f8df/record-c28895c237c8/record-ad98ac505def.json)
- [record-74390e94f8df/record-c28895c237c8/record-d2145d2308cc.json](record-74390e94f8df/record-c28895c237c8/record-d2145d2308cc.json)
- [record-74390e94f8df/record-c28895c237c8/record-ff25d304c6eb.json](record-74390e94f8df/record-c28895c237c8/record-ff25d304c6eb.json)
- [record-74390e94f8df/record-d116a0915779/live_revocation_parallel.py](record-74390e94f8df/record-d116a0915779/live_revocation_parallel.py)
- [record-74390e94f8df/record-d116a0915779/probe_samples.csv.gz](record-74390e94f8df/record-d116a0915779/probe_samples.csv.gz)
- [record-74390e94f8df/record-d116a0915779/record-f8eb2cb79322.json](record-74390e94f8df/record-d116a0915779/record-f8eb2cb79322.json)
- [record-74390e94f8df/record-d116a0915779/result.json](record-74390e94f8df/record-d116a0915779/result.json)
- [record-74390e94f8df/record-d116a0915779/revocation_parallel.png](record-74390e94f8df/record-d116a0915779/revocation_parallel.png)
- [record-74390e94f8df/record-d116a0915779/revocation_parallel.svg](record-74390e94f8df/record-d116a0915779/revocation_parallel.svg)
- [record-74390e94f8df/record-d116a0915779/rounds.csv](record-74390e94f8df/record-d116a0915779/rounds.csv)
- [record-74390e94f8df/record-d116a0915779/summary.csv](record-74390e94f8df/record-d116a0915779/summary.csv)
- [record-74390e94f8df/record-d116a0915779/worker_rounds.csv](record-74390e94f8df/record-d116a0915779/worker_rounds.csv)
- [record-74390e94f8df/record-ff34439ff737.md](record-74390e94f8df/record-ff34439ff737.md)