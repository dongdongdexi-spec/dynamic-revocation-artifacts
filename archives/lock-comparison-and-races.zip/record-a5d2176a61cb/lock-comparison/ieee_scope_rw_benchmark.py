"""Matched durable-delivery benchmark for global and per-scope lock policies."""

import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import platform
from queue import Queue
from random import Random
import socketserver
import sqlite3
import threading

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from ieee_end_to_end_delivery import (GatewayHandler, GatewayServer, NOW, SCALES, WAIT, aad, from_worker,
                                      proof, read_frame, request, start_workers, stats, stop_workers,
                                      write_csv, write_frame)
from ieee_scope_locks import GlobalLock, ScopeRWLocks


MODES = {'global': GlobalLock, 'rwlock': ScopeRWLocks}
WORKLOADS = ('hot', 'multi')
ROUNDS = ('retained', 'queued', 'retained', 'late_ack', 'queued', 'retained', 'queued', 'retained', 'late_ack', 'queued')
SCOPES = tuple(f'scope-{i}' for i in range(8)) + ('control',)
TARGET = SCOPES[0]
SEED = 20261125


def job_fields(job):
    return tuple(job[k] for k in ('epoch', 'scope', 'recipient'))


def make_body(pair_id, scope):
    return f'SYNTHETIC:{pair_id}:{scope}:' + hashlib.shake_256(pair_id.encode()).hexdigest(96)


class DurableWriter:
    """One persistent, durable SQLite writer shared by both lock policies."""

    def __init__(self, database):
        self.inbox = Queue()
        self.ready = threading.Event()
        self.error = None
        self.thread = threading.Thread(target=self.run, args=(database,))
        self.thread.start()
        if not self.ready.wait(WAIT) or self.error is not None:
            raise RuntimeError('Could not start SQLite writer') from self.error

    def run(self, database):
        try:
            with sqlite3.connect(database, timeout=WAIT) as db:
                db.execute('PRAGMA journal_mode=WAL')
                db.execute('PRAGMA synchronous=FULL')
                db.execute('CREATE TABLE receipts(id TEXT PRIMARY KEY, epoch INT, scope TEXT, recipient TEXT, '
                           'body TEXT, sha256 TEXT, receiver_arrival_ns INT, sql_started_ns INT)')
                self.ready.set()
                while (work := self.inbox.get()) is not None:
                    item, arrived, response = work
                    started = NOW()
                    try:
                        with db:
                            db.execute('INSERT INTO receipts VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                                       (item['id'], item['epoch'], item['scope'], item['recipient'], item['body'],
                                        item['sha256'], arrived, started))
                        response.put({'receiver_arrival_ns': arrived, 'sql_started_ns': started,
                                      'receiver_committed_ns': NOW(), 'sha256': item['sha256']})
                    except Exception as exc:
                        response.put(exc)
        except Exception as exc:
            self.error = exc
            self.ready.set()

    def submit(self, item, arrived):
        response = Queue(maxsize=1)
        self.inbox.put((item, arrived, response))
        result = response.get(timeout=WAIT)
        if isinstance(result, Exception):
            raise result
        return result

    def close(self):
        self.inbox.put(None)
        self.thread.join(WAIT)
        if self.thread.is_alive() or self.error is not None:
            raise RuntimeError('SQLite writer did not shut down cleanly') from self.error


class ReceiverHandler(socketserver.StreamRequestHandler):
    def handle(self):
        frame = read_frame(self.rfile)
        if frame['kind'] == 'stop':
            write_frame(self.wfile, {'stopped': True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        if frame['kind'] != 'receive':
            raise ValueError('Unrecognized receiver message type')
        arrived = NOW()
        item = frame['item']
        if item['recipient'] != f'recipient-{item["scope"]}' or proof(item['body']) != item['sha256']:
            raise ValueError('Receipt binding or digest verification failed')
        write_frame(self.wfile, self.server.writer.submit(item, arrived))


class ReceiverServer(socketserver.ThreadingTCPServer):
    daemon_threads = False
    request_queue_size = 256


def receiver_main(path, control):
    writer = DurableWriter(path)
    try:
        with ReceiverServer(('127.0.0.1', 0), ReceiverHandler) as server:
            server.writer = writer
            control.send((server.server_address, os.getpid()))
            control.close()
            server.serve_forever(poll_interval=.02)
    finally:
        writer.close()


@dataclass
class ScopeSlot:
    epoch: int
    key: bytes | None


class MatchedGateway:
    def __init__(self, recipient):
        self.recipient = recipient
        self.condition = threading.Condition()
        self.resume_ack = threading.Event()

    def stage(self, mode, workload, count, trial, scenario):
        self.locks = MODES[mode](SCOPES)
        self.scenario = scenario
        self.resume_ack.clear()
        self.target_deliveries = 0
        self.bindings = {}
        epoch = count * 1000 + trial
        self.slots = {scope: ScopeSlot(epoch, AESGCM.generate_key(256)) for scope in SCOPES}
        staged = []
        for worker in range(count):
            scope = TARGET if workload == 'hot' else SCOPES[worker % 8]
            worker_jobs = []
            for lane in (scope, 'control') if worker == 0 else (scope,):
                pair_id = f'{workload}-{count:02d}-{trial:02d}-{worker:02d}-{lane}'
                job = {'id': f'{mode}-{pair_id}', 'epoch': epoch, 'scope': lane,
                       'recipient': f'recipient-{lane}'}
                body = make_body(pair_id, lane)
                self.bindings[job['id']] = (job_fields(job), proof(body))
                nonce = os.urandom(12)
                encrypted = AESGCM(self.slots[lane].key).encrypt(nonce, body.encode('utf-8'), aad(job))
                worker_jobs.append(job | {'nonce': nonce.hex(), 'ciphertext': encrypted.hex()})
            staged.append(worker_jobs)
        return staged

    def revoke(self):
        requested = NOW()
        with self.locks.write(TARGET):
            acquired = NOW()
            self.slots[TARGET].key = None
            published = NOW()
        return {'scope': TARGET, 'epoch': self.slots[TARGET].epoch, 'requested_ns': requested,
                'acquired_ns': acquired, 'published_ns': published, 'returned_ns': NOW()}

    def process(self, job):
        # Canonical scope comes from the trusted issue-time record, not the request.
        binding, expected = self.bindings[job['id']]
        if job_fields(job) != binding:
            raise ValueError('Delivery binding does not match the issued job')
        epoch, scope, recipient = binding
        started = NOW()
        receiver_arrival = sql_started = committed = decrypt_ns = receiver_rpc_ns = None
        with self.locks.read(scope):
            acquired = NOW()
            slot = self.slots[scope]
            key = slot.key if slot.epoch == epoch else None
            decision = NOW()
            if key is not None:
                body = AESGCM(key).decrypt(bytes.fromhex(job['nonce']), bytes.fromhex(job['ciphertext']), aad(job)).decode()
                decrypt_ns = NOW() - decision
                if proof(body) != expected:
                    raise ValueError('Decrypted value does not match the issued job')
                sent = NOW()
                receiver = request(self.recipient, {'kind': 'receive', 'item': {'id': job['id'], 'epoch': epoch,
                                   'scope': scope, 'recipient': recipient, 'body': body, 'sha256': expected}})
                receiver_rpc_ns = NOW() - sent
                if receiver['sha256'] != expected:
                    raise ValueError('Recipient acknowledged a different payload')
                receiver_arrival, sql_started, committed = (receiver[k] for k in (
                    'receiver_arrival_ns', 'sql_started_ns', 'receiver_committed_ns'))
            end_of_critical_section = NOW()
        if committed is not None and scope == TARGET and self.scenario == 'late_ack':
            with self.condition:
                self.target_deliveries += 1
                self.condition.notify_all()
            if not self.resume_ack.wait(WAIT):
                raise TimeoutError('Coordinator did not release the worker acknowledgment')
        return {'id': job['id'], 'epoch': epoch, 'recipient': recipient, 'expected_digest': expected,
                'allowed': int(key is not None), 'lock_started_ns': started, 'lock_acquired_ns': acquired,
                'decision_ns': decision, 'lock_wait_ns': acquired - started, 'auth_ns': decision - acquired,
                'inside_lock_ns': end_of_critical_section - acquired, 'end_of_critical_section_ns': end_of_critical_section,
                'decrypt_ns': decrypt_ns, 'receiver_rpc_ns': receiver_rpc_ns, 'receiver_arrival_ns': receiver_arrival,
                'sql_started_ns': sql_started, 'receiver_committed_ns': committed,
                'sql_wait_ns': None if sql_started is None else sql_started - receiver_arrival,
                'sql_write_ns': None if committed is None else committed - sql_started,
                'gateway_ack_ns': NOW()}


def run_cell(server, processes, release, mode, workload, count, trial, scenario):
    release.clear()
    gate = server.gateway
    staged = gate.stage(mode, workload, count, trial, scenario)
    for (pipe, _), jobs in zip(processes, staged, strict=True):
        pipe.send(('stage', (scenario, jobs)))
    ready = [from_worker(pipe) for pipe, _ in processes]
    revoke = gate.revoke() if scenario == 'queued' else None
    for pipe, _ in processes:
        pipe.send(('send', scenario))
    release.set()
    if scenario == 'late_ack':
        target_count = sum(job['scope'] == TARGET for jobs in staged for job in jobs)
        with gate.condition:
            if not gate.condition.wait_for(lambda: gate.target_deliveries == target_count, timeout=WAIT):
                raise TimeoutError('Pre-revocation target commits did not finish')
        revoke = gate.revoke()
        gate.resume_ack.set()
    finished = [from_worker(pipe) for pipe, _ in processes]
    assert len({r[0] for r in finished}) == count
    cell = {'mode': mode, 'workload': workload, 'workers': count, 'round': trial, 'scenario': scenario}
    rows = []
    for index, (stage, finish) in enumerate(zip(ready, finished, strict=True)):
        pid, _, results = finish
        assert stage[0] == pid
        rows.extend(cell | {'worker': index, 'pid': pid, 'staged_ns': stage[1]} | row for row in results)
    return rows, None if revoke is None else cell | revoke


def audit(rows, events, database):
    def cell(row):
        return tuple(row[k] for k in ('mode', 'workload', 'workers', 'round'))

    with sqlite3.connect(database) as db:
        persisted = {item[0]: item[1:] for item in db.execute('SELECT * FROM receipts')}
    revokes = {(cell(event), event['epoch'], event['scope']): event for event in events}
    for event in revokes.values():
        assert event['requested_ns'] <= event['acquired_ns'] <= event['published_ns'] <= event['returned_ns']
    paired = defaultdict(dict)
    counts = Counter()
    for row in rows:
        assert row['staged_ns'] <= row['dispatched_ns'] <= row['lock_started_ns'] <= row['lock_acquired_ns']
        assert row['lock_acquired_ns'] <= row['decision_ns'] <= row['gateway_ack_ns'] <= row['worker_ack_ns']
        event = revokes.get((cell(row), row['epoch'], row['scope']))
        assert (event is not None) == (row['scope'] == TARGET and row['scenario'] != 'retained')
        if row['allowed']:
            epoch, scope, recipient, body, digest, arrived, written = persisted.pop(row['id'])
            assert (epoch, scope, recipient) == job_fields(row)
            assert proof(body) == digest == row['expected_digest']
            assert arrived == row['receiver_arrival_ns'] and written == row['sql_started_ns']
            assert row['decision_ns'] <= arrived <= written <= row['receiver_committed_ns']
            assert row['receiver_committed_ns'] <= row['end_of_critical_section_ns'] <= row['gateway_ack_ns']
            counts['durable_receipts'] += 1
            if event is not None:
                assert row['scenario'] == 'late_ack'
                assert row['receiver_committed_ns'] < event['published_ns'] < row['worker_ack_ns']
                counts['target_precommit_late_ack'] += 1
        else:
            assert event is not None and row['decision_ns'] >= event['published_ns']
            assert row['id'] not in persisted and row['receiver_committed_ns'] is None and row['decrypt_ns'] is None
            counts['post_revocation_target_denied'] += 1
        if row['scope'] != TARGET or row['scenario'] == 'retained':
            assert row['allowed']
        if row['scope'] == 'control':
            counts['unrelated_control_received'] += 1
        pair_id = row['id'].split('-', 1)[1]
        assert row['mode'] not in paired[pair_id]
        paired[pair_id][row['mode']] = (row['allowed'], row['expected_digest'])
    assert not persisted
    assert all(p['global'] == p['rwlock'] for p in paired.values())
    return dict(counts) | {'matched_pairs': len(paired), 'retired_scope_commits_at_or_after_revocation': 0}


def summarize(rows, events):
    groups = defaultdict(list)
    event_groups = defaultdict(list)
    for row in rows:
        groups[row['mode'], row['workload'], row['workers']].append(row)
    for event in events:
        event_groups[event['mode'], event['workload'], event['workers']].append(event)
    output = {workload: {mode: {} for mode in MODES} for workload in WORKLOADS}
    for (mode, workload, workers), group in groups.items():
        # Only predeclared normal no-revocation rounds are in the latency comparison.
        normal = [r for r in group if r['scenario'] == 'retained' and r['scope'] != 'control']
        cell = {key: stats([r[key] for r in normal]) for key in ('e2e_ns', 'lock_wait_ns', 'auth_ns',
                'inside_lock_ns', 'decrypt_ns', 'receiver_rpc_ns', 'sql_wait_ns', 'sql_write_ns')}
        changes = event_groups[mode, workload, workers]
        cell['revoke_to_publication_ns'] = stats([r['published_ns'] - r['requested_ns'] for r in changes])
        cell['revoke_inside_lock_ns'] = stats([r['published_ns'] - r['acquired_ns'] for r in changes])
        cell['batch_elapsed_ns'] = stats([max(r['worker_ack_ns'] for r in normal if r['round'] == trial) -
                                         min(r['dispatched_ns'] for r in normal if r['round'] == trial)
                                         for trial in {r['round'] for r in normal}])
        output[workload][mode][workers] = cell
    return output


def benchmark(args):
    args.out.mkdir(parents=True, exist_ok=True)
    database = args.out / 'receipts.sqlite'
    if database.exists():
        raise ValueError('Choose a fresh output directory')
    rows, events = [], []
    rng = Random(SEED)
    ctx = mp.get_context('spawn')
    parent, child = ctx.Pipe(duplex=False)
    receiver = ctx.Process(target=receiver_main, args=(database, child))
    receiver.start()
    child.close()
    try:
        address, recipient_pid = from_worker(parent)
        with GatewayServer(('127.0.0.1', 0), GatewayHandler) as server:
            server.gateway = MatchedGateway(address)
            thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
            thread.start()
            try:
                for count in args.workers:
                    print(f'Running {count} independent workers', flush=True)
                    release = ctx.Event()
                    processes = start_workers(ctx, server.server_address, release, args.out, count)
                    try:
                        for workload in WORKLOADS:
                            for trial, scenario in enumerate(ROUNDS * args.cycles, start=1):
                                modes = list(MODES)
                                rng.shuffle(modes)
                                for order, mode in enumerate(modes):
                                    trial_rows, event = run_cell(server, processes, release, mode, workload, count, trial, scenario)
                                    rows.extend({'arm_order': order, **row} for row in trial_rows)
                                    if event is not None:
                                        events.append({'arm_order': order, **event})
                    finally:
                        stop_workers(processes)
            finally:
                server.shutdown()
                thread.join()
        request(address, {'kind': 'stop'})
        receiver.join(WAIT)
        if receiver.exitcode != 0:
            raise RuntimeError(f'Receiver exit code {receiver.exitcode}')
        verification = audit(rows, events, database)
        write_csv(args.out / 'deliveries.csv', rows)
        write_csv(args.out / 'revocations.csv', events)
        result = {'python': platform.python_version(), 'platform': platform.platform(), 'logical_cpus': os.cpu_count(),
                  'gateway_pid': os.getpid(), 'receiver_pid': recipient_pid, 'worker_counts': args.workers,
                  'workloads': list(WORKLOADS), 'round_schedule': list(ROUNDS), 'cycles': args.cycles,
                  'paired_mode_order_seed': SEED, 'verification': verification, 'cells': summarize(rows, events)}
        (args.out / 'summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(verification), flush=True)
    finally:
        parent.close()
        if receiver.is_alive():
            receiver.terminate()
            receiver.join()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workers', nargs='+', type=int, default=SCALES)
    parser.add_argument('--cycles', type=int, default=1)
    args = parser.parse_args()
    if not 1 <= args.cycles <= 4 or any(count < 1 for count in args.workers):
        parser.error('worker counts must be positive and cycles must be between 1 and 4')
    benchmark(args)
