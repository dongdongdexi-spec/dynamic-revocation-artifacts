"""Render the matched benchmark artifact from its archived summary."""

import argparse
import csv
import json
from pathlib import Path
from statistics import median, quantiles


LABELS = {'hot': 'Hot scope', 'multi': 'Eight scopes'}
MODE_LABELS = {'global': 'Global mutex', 'rwlock': 'Per-scope RWLock'}
COLORS = {'global': '#9e4a21', 'rwlock': '#0c6480'}


def pair(values, unit=1e6):
    return f'{values["p50_ns"] / unit:,.3f} / {values["p95_ns"] / unit:,.3f}'


def plot(cells, counts, destination):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'svg.fonttype': 'none'})
    fig, charts = plt.subplots(1, 2, figsize=(9.4, 3.8), sharey=True)
    positions = range(len(counts))
    upper = 1.08 * max(cells[workload][mode][str(count)]['e2e_ns']['p95_ns'] / 1e6
                       for workload in LABELS for mode in MODE_LABELS for count in counts)
    for chart, workload in zip(charts, LABELS, strict=True):
        for mode in MODE_LABELS:
            values = [cells[workload][mode][str(count)]['e2e_ns'] for count in counts]
            chart.plot(positions, [v['p95_ns'] / 1e6 for v in values], '-o', color=COLORS[mode],
                       linewidth=2.2, markersize=5)
            chart.plot(positions, [v['p50_ns'] / 1e6 for v in values], '--s', color=COLORS[mode],
                       linewidth=1.45, markersize=4)
        chart.set(title=LABELS[workload], xlabel='Independent delivery workers',
                  xticks=list(positions), xticklabels=counts)
        chart.set_ylim(0, upper)
        chart.grid(axis='y', alpha=.22)
        chart.spines[['top', 'right']].set_visible(False)
    charts[0].set_ylabel('Authorized round trip (ms)')
    handles = [Line2D([], [], color=COLORS[k], lw=2.25, label=v) for k, v in MODE_LABELS.items()]
    handles.extend([Line2D([], [], color='#555555', lw=1.5, linestyle='--', marker='s', label='p50'),
                    Line2D([], [], color='#555555', lw=2, linestyle='-', marker='o', label='p95')])
    fig.legend(handles=handles, loc='lower center', frameon=False, ncol=4, bbox_to_anchor=(.5, .01))
    fig.subplots_adjust(left=.10, right=.98, bottom=.26, top=.89, wspace=.12)
    fig.savefig(destination / 'fig2_matched_rwlock.png', dpi=240, facecolor='white')
    fig.savefig(destination / 'fig2_matched_rwlock.svg', facecolor='white')
    plt.close(fig)


def report(summary, out):
    cells = summary['cells']
    counts = summary['worker_counts']
    audit = summary['verification']
    cycles = summary['cycles']
    rows = ['# 全局互斥锁与按作用域读写锁的同条件对照', '',
            '同一测试框架比较全局互斥锁与写者优先的按作用域读写锁。两组共用 TCP 消息、并发接收端和单 SQLite 写入队列。'
            '接收端以 WAL、`synchronous=FULL` 为每条正文独立完成一次事务，再发送确认。'
            '前一轮论文中的全局锁数据来自串行接收服务器，该数据单独保留。', '',
            f'每个规模和每种负载运行 {cycles * 10} 对轮次，其中 {cycles * 4} 对为不撤权的正常授权交付。'
            f'工作进程数为 {"、".join(str(x) for x in counts)}，轮次内随机决定先测哪种锁。'
            f'配对的应用正文逐字节相同，每组独立颁发带随机密钥和 nonce 的认证密文。'
            '热作用域把主要交付都放在同一作用域。多作用域把主要交付按工作进程均分到八个作用域，低于八个工作进程时只用实际覆盖的作用域。'
            '每轮额外有一条独立作用域的授权哨兵。下表正常授权耗时排除哨兵、撤权轮和故意延迟确认轮。', '',
            '### 正常授权交付与锁开销', '',
            '| 负载 | 工作进程 | 样本/组 | 全局往返（ms） | 分片往返（ms） | 全局等待锁（ms） | 分片等待锁（ms） |',
            '|---|---:|---:|---:|---:|---:|---:|']
    for workload in LABELS:
        for count in counts:
            g, r = (cells[workload][m][str(count)] for m in MODE_LABELS)
            rows.append(f'| {LABELS[workload]} | {count} | {g["e2e_ns"]["n"]} | {pair(g["e2e_ns"])} |'
                        f' {pair(r["e2e_ns"])} | {pair(g["lock_wait_ns"])} | {pair(r["lock_wait_ns"])} |')
    rows.extend(['', '每个单元格为 p50 / p95。`summary.json` 同时记录锁内核权、持锁区间、正文解密、'
                 '接收端 RPC、SQLite 写队列等待、独立持久化事务，以及从撤权请求到生效发布的时间。'
                 '`deliveries.csv` 和 `revocations.csv` 给出每条对应时间戳。',
                 '', '![两类锁在两种负载下的授权交付往返曲线](fig2_matched_rwlock.png)', '',
                 '### 64 工作进程的分解结果', '',
                 '| 负载 | 指标 | 全局锁 p50 / p95 | 分片锁 p50 / p95 |', '|---|---|---:|---:|'])
    if 64 in counts:
        with (out / 'revocations.csv').open(encoding='utf-8', newline='') as stream:
            changes = list(csv.DictReader(stream))
        def writer_wait(workload, mode):
            values = [int(r['acquired_ns']) - int(r['requested_ns']) for r in changes
                      if r['workload'] == workload and r['mode'] == mode and r['workers'] == '64']
            return pair({'p50_ns': median(values), 'p95_ns': quantiles(values, n=100, method='inclusive')[94]})

        for workload in LABELS:
            g, r = (cells[workload][m]['64'] for m in MODE_LABELS)
            for key, label, unit in [('auth_ns', '锁内核权（µs）', 1e3), ('inside_lock_ns', '持锁区间（ms）', 1e6),
                                     ('decrypt_ns', '解密与解码（µs）', 1e3), ('receiver_rpc_ns', '接收端 RPC（ms）', 1e6),
                                     ('sql_wait_ns', 'SQLite 写队列等待（ms）', 1e6),
                                     ('sql_write_ns', '每条 SQLite 事务（ms）', 1e6),
                                     ('revoke_to_publication_ns', '撤权请求到发布（ms）', 1e6)]:
                rows.append(f'| {LABELS[workload]} | {label} | {pair(g[key], unit)} | {pair(r[key], unit)} |')
            rows.append(f'| {LABELS[workload]} | 撤权锁等待（ms） | {writer_wait(workload, "global")} |'
                        f' {writer_wait(workload, "rwlock")} |')
        rows.append('')
        for workload in LABELS:
            g, r = (cells[workload][m]['64']['e2e_ns']['p95_ns'] / 1e6 for m in MODE_LABELS)
            rows.append(f'{LABELS[workload]} 的 64 进程正常交付 p95 为全局锁 {g:.3f} ms、分片锁 {r:.3f} ms。'
                        f'分片减去全局的差值为 {r-g:+.3f} ms。')
    rows.extend(['', '撤权时间分位数仅适用于有撤权事件的轮次。排队后撤权轮在请求派发前生效，迟确认轮则在目标正文已持久化后生效。'
                 '此处的撤权请求到发布分布描述这些控制时序。正常交付延迟分解的不同分位数不可相加。', '',
                 '### 顺序保证与收件复核', '',
                 '提交使用可信预注册工单中的作用域，先核验请求绑定，再获取读锁。读锁保留到受信任接收端确认正文已持久化，'
                 '同作用域撤权取得写锁后才使密钥槽失效并记录发布时点。已排队的写者会阻止新读者获取同一作用域的锁。'
                 '不同作用域可以读写不同槽。同一个 SQLite 文件仍然只有一个写者，读锁并行允许更多正文进入接收端写队列。'
                 '本对照覆盖可靠接收确认的正常路径。网关与接收端之间确认结果未知时，使用另一个竞态与恢复实验的协议。', '',
                 f'共 {audit["matched_pairs"]:,} 对请求、{audit["durable_receipts"]:,} 条实际持久化收件。'
                 f'撤权后目标作用域的 {audit["post_revocation_target_denied"]:,} 条提交均拒绝，'
                 f'实际收件中生效后撤销作用域提交为 {audit["retired_scope_commits_at_or_after_revocation"]}。'
                 f'独立哨兵 {audit["unrelated_control_received"]:,} 条全部实收。'
                 f'{audit["target_precommit_late_ack"]:,} 条目标正文在撤权前已持久化，派发方于撤权后才收到确认。'
                 '审计按工单标识、作用域和 epoch 把正文、摘要、提交时刻与撤权事件关联，同时检查两种锁下的请求与处理结果逐项配对。', '',
                 '### 复跑', '',
                 f'本次执行环境为 Python {summary["python"]}，{summary["platform"]}，{summary["logical_cpus"]} 个逻辑 CPU。'
                 '需安装 `cryptography` 和 `matplotlib`，在本目录运行以下命令。', '', '```powershell',
                 f'python -B -X utf8 ieee_scope_rw_benchmark.py --workers {" ".join(str(x) for x in counts)} --cycles {cycles} --out rerun',
                 'python -B -X utf8 ieee_scope_rw_report.py rerun', '```', ''])
    (out / '分片读写锁对照.md').write_text('\n'.join(rows), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    summary = json.loads((args.directory / 'summary.json').read_text(encoding='utf-8'))
    report(summary, args.directory)
    plot(summary['cells'], summary['worker_counts'], args.directory)


if __name__ == '__main__':
    main()
