"""Independently join raw paired gateway runs with the durable receipt database."""

import argparse
from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
from math import isclose
from pathlib import Path
import sqlite3
from statistics import median, quantiles


def load_csv(path, numeric):
    with path.open(encoding='utf-8', newline='') as stream:
        for record in csv.DictReader(stream):
            yield dict(record, **{k: int(record[k]) if record[k] else None for k in numeric})


def cell(row):
    return row['mode'], row['workload'], row['workers'], row['round']


def percentiles(values):
    return median(values), quantiles(values, n=100, method='inclusive')[94]


def check_pair(expected, measured):
    assert all(isclose(expected[k], actual, abs_tol=1e-6)
               for k, actual in zip(('p50_ns', 'p95_ns'), measured, strict=True))


def audit(path):
    benchmark = json.loads((path / 'summary.json').read_text(encoding='utf-8'))
    deliveries = list(load_csv(path / 'deliveries.csv', ('workers', 'round', 'worker', 'epoch', 'pid',
               'allowed', 'arm_order', 'lock_started_ns', 'lock_acquired_ns', 'decision_ns', 'e2e_ns',
               'lock_wait_ns', 'auth_ns', 'decrypt_ns', 'dispatched_ns', 'receiver_arrival_ns',
               'sql_started_ns', 'sql_wait_ns', 'sql_write_ns', 'receiver_committed_ns', 'worker_ack_ns')))
    revocations = list(load_csv(path / 'revocations.csv', ('workers', 'round', 'epoch', 'arm_order',
                      'requested_ns', 'acquired_ns', 'published_ns', 'returned_ns')))
    revokes = {(cell(r), r['scope'], r['epoch']): r for r in revocations}
    assert len(revokes) == len(revocations)
    for r in revocations:
        assert r['requested_ns'] <= r['acquired_ns'] <= r['published_ns'] <= r['returned_ns']

    with sqlite3.connect(path / 'receipts.sqlite') as conn:
        assert conn.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        records = conn.execute('SELECT id, epoch, scope, recipient, body, sha256 FROM receipts').fetchall()
    by_id = {key: (epoch, scope, dst, body, digest) for key, epoch, scope, dst, body, digest in records}
    assert len(by_id) == len(records)
    assert set(by_id) == {r['id'] for r in deliveries if r['allowed']}
    assert len({r['id'] for r in deliveries}) == len(deliveries)

    counts = Counter()
    pair_by_id = defaultdict(list)
    process_ids = defaultdict(dict)
    routine = defaultdict(list)
    for r in deliveries:
        pair_by_id[r['id'].split('-', 1)[1]].append(r)
        process_ids[cell(r)][r['worker']] = r['pid']
        assert r['lock_wait_ns'] == r['lock_acquired_ns'] - r['lock_started_ns']
        assert r['auth_ns'] == r['decision_ns'] - r['lock_acquired_ns']
        assert r['e2e_ns'] == r['worker_ack_ns'] - r['dispatched_ns']
        event = revokes.get((cell(r), r['scope'], r['epoch']))
        if r['allowed']:
            epoch, scope, dst, body, digest = by_id[r['id']]
            assert (epoch, scope, dst) == (r['epoch'], r['scope'], r['recipient'])
            assert sha256(body.encode('utf-8')).hexdigest() == digest == r['expected_digest']
            assert r['receiver_arrival_ns'] <= r['sql_started_ns'] <= r['receiver_committed_ns'] <= r['worker_ack_ns']
            assert r['sql_write_ns'] == r['receiver_committed_ns'] - r['sql_started_ns']
            assert r['sql_wait_ns'] == r['sql_started_ns'] - r['receiver_arrival_ns']
            counts['durable_receipts'] += 1
            if event:
                assert r['receiver_committed_ns'] < event['published_ns'] < r['worker_ack_ns']
                counts['target_precommit_late_ack'] += 1
        else:
            assert event and r['decision_ns'] >= event['published_ns']
            assert r['decrypt_ns'] is None and r['receiver_committed_ns'] is None
            counts['post_revocation_target_denied'] += 1
        if r['scope'] == 'control':
            assert r['allowed']
            counts['unrelated_control_received'] += 1
        if r['scenario'] == 'retained' and r['scope'] != 'control':
            assert r['allowed']
            routine[cell(r)[:3]].append(r)

    for (_, _, workers, _), pids in process_ids.items():
        assert set(pids) == set(range(workers))
        assert len(set(pids.values())) == workers
        assert benchmark['receiver_pid'] not in pids.values()
    for pair in pair_by_id.values():
        assert len(pair) == 2 and {r['mode'] for r in pair} == {'global', 'rwlock'}
        assert {r['arm_order'] for r in pair} == {0, 1}
        assert len({tuple(r[k] for k in ('workload', 'workers', 'round', 'worker', 'scope', 'epoch',
                         'recipient', 'scenario', 'expected_digest', 'allowed')) for r in pair}) == 1

    revocation_wait = {}
    for (mode, workload, workers), observations in routine.items():
        summary = benchmark['cells'][workload][mode][str(workers)]
        for metric in ('e2e_ns', 'lock_wait_ns', 'auth_ns', 'decrypt_ns', 'sql_wait_ns', 'sql_write_ns'):
            check_pair(summary[metric], percentiles([r[metric] for r in observations]))
        changes = [r for r in revocations if cell(r)[:3] == (mode, workload, workers)]
        this_revoke_wait = percentiles([r['acquired_ns'] - r['requested_ns'] for r in changes])
        check_pair(summary['revoke_to_publication_ns'],
                   percentiles([r['published_ns'] - r['requested_ns'] for r in changes]))
        assert all(v >= 0 for v in this_revoke_wait)
        revocation_wait[f'{workload}:{mode}:{workers}'] = dict(zip(('p50', 'p95'), this_revoke_wait, strict=True))

    check = dict(counts, matched_pairs=len(pair_by_id), retired_scope_commits_at_or_after_revocation=0)
    assert check == benchmark['verification'], (check, benchmark['verification'])
    return {'requests': len(deliveries), 'revocation_events': len(revocations),
            'paired_measurement_cells': len(routine), **check,
            'revocation_lock_wait_by_cell_ns': revocation_wait}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('data', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    evidence = audit(args.data)
    args.out.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(evidence))
