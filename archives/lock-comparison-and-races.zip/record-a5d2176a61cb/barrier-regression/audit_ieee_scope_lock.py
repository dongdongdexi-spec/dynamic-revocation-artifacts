"""Exercise the same-scope order and cross-scope progress of the replay lock."""

import argparse
import hashlib
import json
from pathlib import Path
from threading import Event, Thread
from time import monotonic, sleep

from ieee_scope_locks import ScopeRWLocks


WAIT_SECONDS = 5


def require_event(event, label):
    if not event.wait(WAIT_SECONDS):
        raise AssertionError(f'Timed out waiting for {label}')


def check():
    policy = ScopeRWLocks(('revoked', 'other'))
    second_active = Event()
    release_second = Event()
    writer_active = Event()
    release_writer = Event()
    reader_attempted = Event()
    next_reader_active = Event()
    cross_scope = Event()
    order = []
    failures = []
    threads = []

    def run(fn):
        def capture():
            try:
                fn()
            except BaseException as exc:
                failures.append(exc)
        thread = Thread(target=capture, daemon=True)
        threads.append(thread)
        thread.start()

    def second_reader():
        with policy.read('revoked'):
            order.append('second_reader_entered')
            second_active.set()
            require_event(release_second, 'second reader release')

    def writer():
        with policy.write('revoked'):
            order.append('revocation_writer_entered')
            writer_active.set()
            require_event(release_writer, 'writer release')

    def new_reader():
        reader_attempted.set()
        with policy.read('revoked'):
            order.append('subsequent_reader_entered')
            next_reader_active.set()

    def cross_scope_reader():
        with policy.read('other'):
            order.append('unrelated_scope_entered')
            cross_scope.set()

    policy.acquire_read('revoked')
    primary_held = True
    try:
        run(second_reader)
        require_event(second_active, 'two simultaneous readers on one scope')
        run(writer)
        lock = policy._locks['revoked']
        deadline = monotonic() + WAIT_SECONDS
        while monotonic() < deadline:
            with lock._condition:
                if lock._waiting_writers == 1:
                    break
            sleep(0.001)
        else:
            raise AssertionError('Writer never queued behind the readers')
        assert not writer_active.is_set()
        run(new_reader)
        require_event(reader_attempted, 'later same-scope reader attempt')
        run(cross_scope_reader)
        require_event(cross_scope, 'work in unrelated scope while writer is queued')
        assert not next_reader_active.is_set()
        run(lambda: policy.release_read('revoked'))
        primary_held = False
        release_second.set()
        require_event(writer_active, 'writer acquisition after readers drained')
        assert not next_reader_active.is_set()
        release_writer.set()
        require_event(next_reader_active, 'later reader after writer released')
    finally:
        if primary_held:
            policy.release_read('revoked')
        release_second.set()
        release_writer.set()
        for thread in threads:
            thread.join(WAIT_SECONDS)
    assert not failures, failures
    assert all(not thread.is_alive() for thread in threads)
    assert order == ['second_reader_entered', 'unrelated_scope_entered',
                     'revocation_writer_entered', 'subsequent_reader_entered']

    for method in (policy.read, policy.write):
        try:
            with method('revoked'):
                raise ValueError('intentional exception')
        except ValueError:
            pass
    with policy.write('revoked'):
        pass
    try:
        policy.read('unissued_scope')
    except KeyError:
        pass
    else:
        raise AssertionError('An unknown scope unexpectedly received a lock')
    return order


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    order = check()
    module = Path(__file__).with_name('ieee_scope_locks.py')
    result = {'trace_order': order, 'same_scope_reads_overlap': True, 'waiting_writer_precedes_new_reader': True,
              'unrelated_scope_progress_with_waiting_writer': True, 'scope_lease_cross_thread_release': True,
              'context_release_on_exception': True, 'unissued_scope_rejected': True,
              'lock_module_sha256': hashlib.sha256(module.read_bytes()).hexdigest()}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))
