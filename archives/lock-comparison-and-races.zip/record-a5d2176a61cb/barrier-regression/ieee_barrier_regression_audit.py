"""Independently audit recipient ledgers produced by the original barrier benchmark."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sqlite3


SCALES = (1, 6, 16, 32, 64)
CONTROL_SCENARIOS = {'authorized', 'late_ack'}
BLOCKED_SCENARIOS = {'queued', 'late', 'partial', 'restart'}
RECEIPT_FIELDS = ('id', 'epoch', 'scope', 'recipient', 'body', 'sha256', 'received_ns')


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def audit(directory):
    ledger = directory / '实收账本.sqlite'
    wal = ledger.with_name(f'{ledger.name}-wal')
    check(not wal.exists() or wal.stat().st_size == 0, 'Expected a settled database with an empty WAL')
    with sqlite3.connect(ledger.resolve().as_uri() + '?mode=ro&immutable=1', uri=True) as db:
        check(db.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'SQLite integrity check failed')
        rows = db.execute(f'SELECT {", ".join(RECEIPT_FIELDS)} FROM receipts').fetchall()

    entries = {row[0]: dict(zip(RECEIPT_FIELDS, row, strict=True)) for row in rows}
    check(len(entries) == len(rows), 'Repeated id in recipient ledger')
    receivers = {row['recipient'] for row in entries.values()}
    check(len(receivers) == 1, 'Expected exactly one receiver identity')

    trace_path = directory / '逐提交轨迹.csv'
    with trace_path.open(encoding='utf-8', newline='') as stream:
        trace = list(csv.DictReader(stream))

    seen = set()
    counts = Counter()
    per_scenario = defaultdict(Counter)
    per_scale = defaultdict(Counter)
    rounds = defaultdict(set)
    workers = defaultdict(set)

    for item in trace:
        code = item['id']
        check(code not in seen, f'Duplicate trace id {code}')
        seen.add(code)
        scope = item['scope']
        scenario = item['scenario']
        check(scope in {'protected', 'independent'}, f'Unknown scope for {code}')
        check(scenario in CONTROL_SCENARIOS | BLOCKED_SCENARIOS, f'Unknown scenario for {code}')

        scale, trial, worker = (int(item[key]) for key in ('workers', 'round', 'worker'))
        rounds[scale].add(trial)
        workers[scale, trial].add(worker)
        publish = int(item['revoke_ns']) if item['revoke_ns'] else None
        decision, client_send, client_ack = (int(item[key]) for key in ('decision_ns', 'dispatched_ns', 'worker_ack_ns'))
        check(client_send <= decision <= client_ack, f'Decision outside requester times for {code}')
        check((publish is None) == (scenario == 'authorized'), f'Unexpected revocation event for {code}')

        expected = scope == 'independent' or scenario in CONTROL_SCENARIOS
        check(expected == (item['allowed'] == '1') == (code in entries), f'Receipt differs from expected barrier ordering for {code}')

        if expected:
            entry = entries[code]
            computed_digest = hashlib.sha256(entry['body'].encode('utf-8')).hexdigest()
            check(computed_digest == entry['sha256'] == item['expected_body_sha256'], f'Body digest mismatch for {code}')
            check(entry['epoch'] == scale * 1000 + trial and entry['scope'] == scope, f'Scope or epoch mismatch for {code}')
            commit = int(item['receiver_committed_ns'])
            check(decision <= entry['received_ns'] == int(item['receiver_received_ns']) <= commit <= client_ack,
                  f'Invalid recipient times for {code}')
            if scope == 'independent':
                metric = 'independent_delivered'
            elif publish is None:
                metric = 'authorization_positive'
            else:
                check(commit < publish < client_ack, f'The delayed ACK must follow a pre-revocation commit for {code}')
                metric = 'known_late_ack'
        else:
            check(decision >= publish and not item['receiver_committed_ns'], f'Invalid deny or receipt at {code}')
            metric = 'revoked_blocked'

        if scenario == 'restart':
            check(item['queued_pid'] != item['dispatch_pid'] and int(item['stage_ns']) <= publish < int(item['result_ready_ns']),
                  f'Replacement process not observed after revocation for {code}')

        for bucket in (counts, per_scenario[scenario], per_scale[scale]):
            bucket[metric] += 1

    check(entries.keys() <= seen, 'Recipient contains a body without a submission trace')
    check(tuple(sorted(rounds)) == SCALES, 'Wrong worker scales')
    check(all(trials == set(range(1, 13)) for trials in rounds.values()), 'Expected 12 rounds at each scale')
    check(all(ids == set(range(scale)) for (scale, _), ids in workers.items()), 'Wrong worker count in a round')
    check(len(trace) == 2856 and len(entries) == 1666, 'Unexpected regression sample count')

    return {
        'traces': len(trace), 'receipts': len(entries), 'post_revocation_protected_receipts': 0,
        'receipt_hash_mismatches': 0, 'counts': dict(counts),
        'per_scenario': {key: dict(value) for key, value in sorted(per_scenario.items())},
        'per_scale': {str(key): dict(value) for key, value in sorted(per_scale.items())},
        'data_sha256': {'trace': sha256(trace_path), 'ledger': sha256(ledger)},
    }


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('fresh', type=Path)
    args.add_argument('reference', type=Path)
    chosen = args.parse_args()
    fresh, reference = audit(chosen.fresh), audit(chosen.reference)
    check({k: v for k, v in fresh.items() if k != 'data_sha256'} ==
          {k: v for k, v in reference.items() if k != 'data_sha256'}, 'Fresh and reference outcomes differ')

    code_names = ('ieee_end_to_end_delivery.py', 'ieee_end_to_end_report.py')
    code_hashes = {name: sha256(chosen.fresh / name) for name in code_names}
    check(code_hashes == {name: sha256(chosen.reference / name) for name in code_names}, 'Archived code differs from reference')
    out = {'source_hashes': code_hashes, 'fresh': fresh, 'archived_reference': reference}
    (chosen.fresh / '账本独立回归核验.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f"Fresh and archived barrier cases both passed. Each has {fresh['traces']:,} submissions and {fresh['receipts']:,} verified receipts.")


if __name__ == '__main__':
    main()
