"""Recompute the fault campaign outcomes from trace and receiver ledger."""

import argparse
import csv
import hashlib
import json
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median, quantiles


def csv_rows(path):
    with path.open(encoding='utf-8', newline='') as stream:
        rows = list(csv.DictReader(stream))
    integers = ('t_ns', 'epoch', 'attempt', 'start_ns', 'end_ns', 'worker_pid')
    for row in rows:
        for name in integers:
            if row.get(name):
                row[name] = int(row[name])
    return rows


def event_times(rows, name, field='id'):
    values = {r[field]: r['t_ns'] for r in rows if r['event'] == name}
    assert len(values) == sum(r['event'] == name for r in rows)
    return values


def durations(values):
    if not values:
        return None
    return {'n': len(values), 'p50_ms': median(values) / 1e6,
            'p95_ms': quantiles(values, n=100, method='inclusive')[94] / 1e6 if len(values) > 1 else values[0]/1e6,
            'max_ms': max(values) / 1e6}


def audit(root):
    campaign = json.loads((root / 'campaign.json').read_text(encoding='utf-8'))
    requests = csv_rows(root / 'requests.csv')
    gateway = csv_rows(root / 'gateway_events.csv')
    receiver = csv_rows(root / 'receiver_events.csv')
    operations = {r['id']: r for r in requests if r['action'] == 'first_submission'}
    assert len(operations) == sum(c['workers'] * campaign['items'] for c in campaign['runs'])
    assert len({r['id'] for r in requests}) == len(operations)
    assert all(r['end_ns'] >= r['start_ns'] and r['status'] != 'transport_unknown' for r in requests)
    with sqlite3.connect(root / 'receipts.sqlite') as db:
        assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        receipts = {r[0]: r[1:] for r in db.execute('SELECT * FROM receipts')}
        fences = {(r[0], r[1]) for r in db.execute("SELECT id, attempt FROM attempts WHERE state='fenced'")}
        assert all('synthetic' in r[3] for r in db.execute('SELECT * FROM operations'))
    assert set(receipts) <= set(operations)
    commits = event_times(receiver, 'committed')
    assert set(commits) == set(receipts)
    settled = {r['id']: r for r in gateway if r['event'] == 'settled'}
    assert set(settled) == set(operations) and len(settled) == sum(r['event'] == 'settled' for r in gateway)
    assert set(receipts) == {i for i,r in settled.items() if r['state'] == 'committed'}
    assert all(r['state'] in ('committed', 'denied') for r in settled.values())
    called = event_times(gateway, 'revoke_requested', 'epoch')
    published = event_times(gateway, 'revoke_published', 'epoch')
    assert set(called) == set(published) == {r['epoch'] for r in campaign['runs']}
    terminal = {(r['id'], r['attempt']): r for r in gateway if r['event'] == 'lease_terminal'}
    auth = {(r['id'], r['attempt']): r for r in gateway if r['event'] == 'authorized'}
    assert set(terminal) == set(auth)
    revoked_body = []
    for id, (scope, epoch, recipient, sha256, body, attempt, inserted) in receipts.items():
        expected = operations[id]
        assert (scope, epoch, sha256) == (expected['scope'], expected['epoch'], expected['sha256'])
        assert recipient == 'synthetic-loopback-recipient'
        assert hashlib.sha256(body.encode()).hexdigest() == sha256
        assert auth[id, attempt]['t_ns'] <= inserted <= commits[id] <= terminal[id, attempt]['t_ns']
        if scope == 'withdrawn' and commits[id] >= published[epoch]:
            revoked_body.append(id)
    assert not revoked_body, revoked_body
    assert {k for k,r in terminal.items() if r['state'] == 'fenced'} == fences
    for (id, attempt), r in auth.items():
        if attempt > 1:
            assert (id, attempt-1) in fences
            assert terminal[id, attempt-1]['t_ns'] <= r['t_ns']
        if r['scope'] == 'withdrawn':
            assert r['t_ns'] <= terminal[id, attempt]['t_ns'] < published[r['epoch']]
    all_denials = [r for r in gateway if r['event'] == 'denied']
    assert all(r['scope'] == 'withdrawn' and published[r['epoch']] <= r['t_ns'] for r in all_denials)
    assert sum(r['scope'] == 'independent' for r in operations.values()) == sum(
        operations[id]['scope'] == 'independent' for id in receipts)
    unknown = {(r['id'], r['attempt']): r for r in gateway if r['event'] == 'uncertain'}
    resolves = {(r['id'], r['attempt']): r for r in gateway if r['event'] == 'receipt_resolved'}
    assert set(unknown) == set(resolves)
    statuses = defaultdict(Counter)
    for id, request in operations.items():
        row = statuses[request['fault']]
        row['operations'] += 1
        row[settled[id]['state']] += 1
        row['reported_pending'] += request['status'] == 'pending'
    rounds = []
    for schedule in campaign['runs']:
        epoch = schedule['epoch']
        req, pub = called[epoch], published[epoch]
        c = [id for id in receipts if operations[id]['epoch'] == epoch and operations[id]['scope'] == 'withdrawn']
        in_flight = [k for k,r in auth.items() if r['epoch'] == epoch and r['scope'] == 'withdrawn' and
                     r['t_ns'] <= req < terminal[k]['t_ns']]
        pending = [k for k in in_flight if k in unknown and unknown[k]['t_ns'] <= req < resolves[k]['t_ns']]
        started_before = sum(r['epoch'] == epoch and r['start_ns'] < req for r in operations.values())
        started_after = sum(r['epoch'] == epoch and r['start_ns'] >= req for r in operations.values())
        assert len({r['worker_pid'] for r in operations.values() if r['epoch'] == epoch}) == schedule['workers']
        rounds.append({**schedule, 'revoke_requested_ns': req, 'revoke_published_ns': pub, 'revoke_wait_ns': pub-req,
                       'withdrawn_committed_before_request': sum(commits[i] < req for i in c),
                       'withdrawn_committed_during_wait': sum(commits[i] >= req for i in c),
                       'withdrawn_denied_after_publish': sum(r['epoch'] == epoch for r in all_denials),
                       'withdrawn_in_flight_at_request': len(in_flight), 'withdrawn_pending_at_request': len(pending),
                       'requests_started_before_revoke': started_before, 'requests_started_after_revoke': started_after})
    recovery = defaultdict(list)
    for k,r in unknown.items():
        recovery[operations[r['id']]['fault']].append(resolves[k]['t_ns'] - r['t_ns'])
    kinds = Counter(r['event'] for r in receiver)
    retry_authorized = sum(a > 1 for _,a in auth)
    assert retry_authorized and kinds['ack_suppressed'] and kinds['precommit_fenced']
    assert kinds['query_reply_withheld'] and kinds['fenced_original_refused']
    assert all(r['event'] != 'rejected_binding' for r in receiver)
    assert any(r['withdrawn_in_flight_at_request'] for r in rounds)
    assert sum(r['withdrawn_committed_before_request'] for r in rounds) and len(all_denials)
    return {'campaign': campaign, 'requests': len(requests), 'operations': len(operations), 'receipts': len(receipts),
            'independent_operations': sum(r['scope'] == 'independent' for r in operations.values()),
            'independent_completed': sum(operations[id]['scope'] == 'independent' for id in receipts),
            'retired_commits_after_revoke': len(revoked_body), 'duplicate_receipts': len(commits)-len(receipts),
            'duplicate_requests': sum(r['action'] == 'concurrent_duplicate' for r in requests),
            'post_revoke_denials': len(all_denials), 'retried_after_fence': retry_authorized,
            'retries_denied_after_fence': sum(r['attempt'] > 1 for r in all_denials),
            'fault_outcomes': {name: dict(v) for name,v in statuses.items()},
            'durable_fences': len(fences), 'receiver_events': dict(kinds),
            'operations_pending_at_30ms': sum(settled[r['id']]['t_ns'] - r['t_ns'] >= campaign['pending_sample_ns']
                                              for r in unknown.values()),
            'receipts_pending_at_30ms': sum(resolves[k]['t_ns'] - r['t_ns'] >= campaign['pending_sample_ns']
                                            for k,r in unknown.items()),
            'operations_seen_pending': len({id for id,_ in unknown}), 'operations_pending_at_finish': 0,
            'recovery': {k: durations(v) for k,v in recovery.items()},
            'recovery_all': durations([v for vs in recovery.values() for v in vs]),
            'revoke_wait': durations([r['revoke_wait_ns'] for r in rounds]), 'rounds': rounds}


def csv_out(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        writer.writerows(rows)


def pair(stat):
    return f"{stat['p50_ms']:.3f} / {stat['p95_ms']:.3f}" if stat else '—'


def report(root, result):
    runs = result['rounds']
    modes = {
        'normal': '正常', 'precommit_failure': '提交前确认失败',
        'lost_ack': '提交后抑制 ACK', 'duplicate': '并行重复调用',
        'late_original': '原请求晚到', 'query_outage': '抑制 ACK 且短时不可查询'}
    before = sum(r['withdrawn_committed_before_request'] for r in runs)
    waiting = sum(r['withdrawn_committed_during_wait'] for r in runs)
    overlap = sum(r['withdrawn_in_flight_at_request'] > 0 for r in runs)
    pending_overlap = sum(r['withdrawn_pending_at_request'] > 0 for r in runs)
    receiver = result['receiver_events']
    lines = [
        '# 自然竞态、确认丢失与幂等恢复实测', '',
        f"6 和 16 个独立下游各跑 4 轮。共 {result['operations']:,} 个逻辑交付、"
        f"{result['requests']:,} 次客户端调用和 {result['receipts']:,} 条核对过摘要的实际收件。"
        f"撤权发布后旧 Epoch 新增正文 **{result['retired_commits_after_revoke']}** 条，"
        f"重复持久化收件 **{result['duplicate_receipts']}** 条，未撤权 scope 正确完成 "
        f"**{result['independent_completed']}/{result['independent_operations']}** 项。", '',
        f"撤权请求发生时，{overlap}/{len(runs)} 轮已有旧 scope 授权持锁交付正在处理，"
        f"{pending_overlap}/{len(runs)} 轮已有旧 scope 回执待核对。{before} 条旧 scope 正文在请求撤权前提交，"
        f"{waiting} 条在写锁等待期间提交，均早于实际撤权发布。另有 {result['post_revoke_denials']} 次旧 scope 拒绝。"
        f"撤权请求到发布的 p50/p95 为 {pair(result['revoke_wait'])} ms（{len(runs)} 轮）。", '',
        '## 按注入模式分组', '',
        '| 预设模式 | 逻辑交付 | 实际收件 | 终态拒绝 | 第一次调用报告待核对 |',
        '|---|---:|---:|---:|---:|',
    ]
    for name,label in modes.items():
        v = result['fault_outcomes'][name]
        lines.append(f"| {label} | {v['operations']} | {v.get('committed',0)} | {v.get('denied',0)} | {v.get('reported_pending',0)} |")
    lines += [
        '',
        f"模式列是为每个交付预先安排的条件。网关先拒绝已撤权交付，对这部分请求并未触发接收端注入。"
        f"接收端实际抑制 {receiver['ack_suppressed']} 个已提交 ACK，持久化 {result['durable_fences']} 个尝试级阻挡记录。"
        f"其中 {result['retried_after_fence']} 个操作在阻挡后获新核权并实际重新提交，"
        f"{result['retries_denied_after_fence']} 个因撤权在重试核权时拒绝。"
        f"有 {receiver['fenced_original_refused']} 个晚到的原尝试被已持久化的阻挡记录拒绝。"
        f"另发出 {result['duplicate_requests']} 个同键并行重复调用，仍只有一个正文可写入该键。", '',
        '## 待核对状态与恢复开销', '',
        f"{result['operations_seen_pending']} 项实际进入待核对。以进入待核对后 30 ms 为观测点，"
        f"{result['receipts_pending_at_30ms']} 项尚未确认接收端事实，"
        f"{result['operations_pending_at_30ms']} 项尚未达到整体终态。试验收尾时待核对为 "
        f"{result['operations_pending_at_finish']} 项。接收端事实查明耗时的总体 p50/p95 为 "
        f"{pair(result['recovery_all'])} ms，共 {result['recovery_all']['n']} 项。", '',
        '| 预设模式 | 实际进入待核对 | 从待核对到接收端事实查明 p50/p95（ms） |',
        '|---|---:|---:|',
    ]
    for name,label in modes.items():
        v = result['recovery'].get(name)
        lines.append(f"| {label} | {v['n'] if v else 0} | {pair(v)} |")
    lines += [
        '',
        f"恢复时间包含预设的短期回复不可用和调度开销。总体最长时间为 {result['recovery_all']['max_ms']:.3f} ms。"
        '并行重复模式有一条非预设的传输结果未知并进入待核对。首次调用列统计客户端标记为首次的请求，'
        '并行重复请求与首次请求两者都可能先抵达网关。', '',
        '## 执行语义与复测', '',
        '下游和可信收件端是独立进程。网关使用按 scope 的写者优先读写锁。工作进程只在轮次开始时统一放行，'
        '撤权线程按冻结种子生成的 25–190 ms 区间延迟独立发出。实际 TCP 和操作系统调度仍会改变事件序列。'
        '收件端使用 SQLite WAL 和 FULL 持久化。在 SQLite COMMIT 完成后、结果可查询或返回前采样单调时钟。', '',
        '操作幂等键绑定 scope、Epoch、接收人和正文摘要。已提交的同键操作返回状态。'
        '查询为空时仍视为待核对。收件端对原尝试建立持久阻挡记录与写正文在同一数据库事务互斥。'
        '只有查到匹配收件或收到持久阻挡确认才结束本次读锁保护。需要重新发送时重新取得读锁并核对当前授权。'
        '接收端回复暂不可用时继续保持读锁，该 scope 的撤权写锁等待，其他 scope 可各自核权交付。'
        '持续不可查询的情况会延迟同 scope 的撤权发布，测试采用接收端可恢复的有限故障。', '',
        '本实验以本机回环、合成正文、已配置作用域和单个可信网关为边界。'
        '交付 RPC 直接传输合成正文，覆盖持久收件、幂等和撤权排序。'
        '密钥槽和密文路径见分片读写锁对照。原有固定时序结果单独保存为 [屏障回归](../00_屏障回归/屏障回归与独立核验.md)。', '',
        '工作目录进入本文件夹后，可以执行以下命令复测与复核。', '',
        '```powershell',
        'python ieee_race_receipts.py --out rerun --workers 6 16 --rounds 4 --items 18 --seed 472019',
        'python ieee_race_report.py --input rerun',
        '```', '',
        '归档 CSV 分别保存客户端调用、网关核权/租约、接收端事件、逐轮撤权时序和按故障模式汇总。'
        'SQLite 账本保留实际正文、尝试阻挡记录和幂等键等证据。', '',
    ]
    (root / '竞态与丢确认实测.md').write_text('\n'.join(lines), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    args = parser.parse_args()
    result = audit(args.input)
    (args.input / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    csv_out(args.input / 'rounds.csv', result['rounds'])
    csv_out(args.input / 'fault_summary.csv', [{'mode': k, **v} for k,v in result['fault_outcomes'].items()])
    report(args.input, result)


if __name__ == '__main__':
    main()
