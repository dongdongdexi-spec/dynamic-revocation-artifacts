"""Independently reconcile the seeded race campaign against its actual SQLite ledger."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sqlite3
from statistics import median, quantiles


def require(condition, why):
    if not condition:
        raise ValueError(why)


def rows(path):
    with path.open(encoding='utf-8', newline='') as file:
        return list(csv.DictReader(file))


def group(items, key):
    indexed = defaultdict(list)
    for item in items:
        indexed[key(item)].append(item)
    return indexed


def one_per_key(items, key, label):
    indexed = group(items, key)
    require(all(len(v) == 1 for v in indexed.values()), f'Duplicate {label}')
    return {k: v[0] for k, v in indexed.items()}


def receipt_identity(item):
    return (item['scope'], int(item['epoch']), item['recipient'], item['sha256'])


def clock(row):
    return int(row['t_ns'])


def distribution(durations):
    if not durations:
        return None
    middle = median(durations)
    upper = quantiles(durations, n=100, method='inclusive')[94] if len(durations) > 1 else middle
    return {'n': len(durations), 'p50_ms': middle / 1e6, 'p95_ms': upper / 1e6}


def audit(path):
    database = path / 'receipts.sqlite'
    wal = database.with_name(database.name + '-wal')
    require(not wal.exists() or not wal.stat().st_size, 'Sender may still be running or DB needs a checkpoint')
    with sqlite3.connect(database.resolve().as_uri() + '?mode=ro&immutable=1', uri=True) as connection:
        connection.row_factory = sqlite3.Row
        require(connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'DB integrity')
        dictionary = lambda table: [dict(r) for r in connection.execute(f'SELECT * FROM {table}')]
        receipt_rows = dictionary('receipts')
        attempt_rows = dictionary('attempts')
        operations = one_per_key(dictionary('operations'), lambda r: r['id'], 'registered operation id')
        receipts = one_per_key(receipt_rows, lambda r: r['id'], 'durable idempotency key')
    gateway = rows(path / 'gateway_events.csv')
    receiver = rows(path / 'receiver_events.csv')
    client = rows(path / 'requests.csv')
    first = one_per_key((r for r in client if r['action'] == 'first_submission'), lambda r: r['id'], 'first submission id')
    commits = one_per_key((r for r in receiver if r['event'] == 'committed'), lambda r: r['id'], 'receiver COMMIT event')
    revokes = one_per_key((r for r in gateway if r['event'] == 'revoke_published'),
                          lambda r: (r['scope'], int(r['epoch'])), 'revocation publication')
    revoke_requests = one_per_key((r for r in gateway if r['event'] == 'revoke_requested'),
                                  lambda r: (r['scope'], int(r['epoch'])), 'revocation request')
    settled = one_per_key((r for r in gateway if r['event'] == 'settled'), lambda r: r['id'], 'gateway terminal event')
    require(set(commits) == set(receipts) <= set(operations) <= set(first), 'Unknown or missing COMMIT, receipt, registration, or submission')
    require(set(revokes) == set(revoke_requests), 'Missing revocation result or start')
    require(all(clock(revoke_requests[k]) <= clock(r) for k, r in revokes.items()), 'Revocation published before request')

    auth = one_per_key((r for r in gateway if r['event'] == 'authorized'),
                       lambda r: (r['id'], int(r['attempt'])), 'fresh authorization per attempt')
    lease_ends = one_per_key((r for r in gateway if r['event'] == 'lease_terminal'),
                             lambda r: (r['id'], int(r['attempt'])), 'durable evidence before read lease release')
    denied = one_per_key((r for r in gateway if r['event'] == 'denied'),
                         lambda r: (r['id'], int(r['attempt'])), 'revocation-based denial per attempt')
    fence_events = one_per_key((r for r in receiver if r['event'] in {'fence_persisted', 'precommit_fenced'}),
                               lambda r: (r['id'], int(r['attempt'])), 'durable fence event')
    fences = one_per_key((r for r in attempt_rows if r['state'] == 'fenced'),
                         lambda r: (r['id'], int(r['attempt'])), 'durable attempt fence')
    require(set(fences) == set(fence_events), 'A fence was not persisted or has no post-COMMIT event')
    require(set(auth) == set(lease_ends), 'An authorized attempt has no terminal evidence associated with its lease')

    receipt_counts = Counter()
    for operation_id, receipt in receipts.items():
        request = first[operation_id]
        stored = operations[operation_id]
        marker = commits[operation_id]
        require(receipt_identity(receipt) == receipt_identity(stored), f'Receipt binding mismatch: {operation_id}')
        require((receipt['scope'], receipt['epoch'], receipt['sha256']) ==
                (request['scope'], int(request['epoch']), request['sha256']), f'Wrong or altered body receipt: {operation_id}')
        require(sha256_text(receipt['body']) == request['sha256'], f'Body digest mismatch: {operation_id}')
        attempt = int(receipt['attempt'])
        lookup = operation_id, attempt
        require(lookup in auth and lookup not in fences, f'Unapproved or fenced attempt committed: {operation_id}')
        require(clock(auth[lookup]) <= int(receipt['inserted_ns']) <= clock(marker), f'Inconsistent receiver COMMIT: {operation_id}')
        require(attempt == int(marker['attempt']), f'Mismatched COMMIT attempt: {operation_id}')
        scope = receipt['scope'], receipt['epoch']
        if scope in revokes:
            require(clock(marker) < clock(revokes[scope]), f'Old epoch COMMIT at/after issuance: {operation_id}')
            if clock(revoke_requests[scope]) < clock(marker):
                receipt_counts['old_committed_during_write_wait'] += 1
        receipt_counts[receipt['scope']] += 1

    for (operation_id, attempt), authorization in auth.items():
        key = authorization['scope'], int(authorization['epoch'])
        terminal = lease_ends[operation_id, attempt]
        if terminal['state'] == 'committed':
            require(operation_id in commits and int(commits[operation_id]['attempt']) == attempt,
                    f'Lease ended for a different committed attempt: {operation_id}')
            evidence = commits[operation_id]
        else:
            require(terminal['state'] == 'fenced' and (operation_id, attempt) in fence_events,
                    f'Lease ended without commit or fence: {operation_id}')
            evidence = fence_events[operation_id, attempt]
        require(clock(authorization) <= clock(evidence) <= clock(terminal), f'Read lease ended before evidence: {operation_id}')
        if key in revokes:
            require(clock(terminal) < clock(revokes[key]), f'Effective revocation overtook an active read lease: {operation_id}')
        if attempt > 1:
            require((operation_id, attempt - 1) in fence_events and
                    clock(fence_events[operation_id, attempt - 1]) < clock(authorization), f'Retry without a confirmed durable fence: {operation_id}')
    for (operation_id, attempt), rejection in denied.items():
        key = rejection['scope'], int(rejection['epoch'])
        require(key in revokes and clock(revokes[key]) <= clock(rejection), f'Premature or wrong scope rejection: {operation_id}')
        if attempt > 1:
            require((operation_id, attempt - 1) in fence_events and
                    clock(fence_events[operation_id, attempt - 1]) < clock(rejection), f'Retry evaluated without durable fence: {operation_id}')

    client_statuses = group(client, lambda r: r['id'])
    for operation_id, request in first.items():
        reported = client_statuses[operation_id]
        for row in reported:
            require(row['scope'] == request['scope'] and row['fault'] == request['fault'] and
                    row['epoch'] == request['epoch'] and row['sha256'] == request['sha256'], f'A retry changed the operation identity: {operation_id}')
            require(int(row['start_ns']) <= int(row['end_ns']), f'Invalid client timestamps: {operation_id}')
            if row['status'] == 'committed':
                require(operation_id in commits and clock(commits[operation_id]) <= int(row['end_ns']),
                        f'Client observed success before durable receipt: {operation_id}')
        if operation_id in settled:
            require((settled[operation_id]['state'] == 'committed') == (operation_id in receipts),
                    f'Agent reconciliation diverges from actual receipt: {operation_id}')

    pending = one_per_key((r for r in gateway if r['event'] == 'uncertain'),
                          lambda r: (r['id'], int(r['attempt'])), 'uncertain attempt')
    resolutions = one_per_key((r for r in gateway if r['event'] == 'receipt_resolved'),
                              lambda r: (r['id'], int(r['attempt'])), 'resolution event')
    require(set(resolutions) <= set(pending), 'Reported a resolution for a request that was never pending')
    for key, outcome in resolutions.items():
        candidate = outcome['id']
        require(clock(outcome) >= clock(pending[key]), f'Resolved before uncertainty: {candidate}')
        known = commits.get(candidate) if outcome['state'] == 'committed' else fence_events.get(key)
        require(known is not None and clock(known) <= clock(outcome), f'Recovery terminal status lacks durable evidence: {candidate}')

    receiver_counts = Counter(row['event'] for row in receiver)
    gateway_counts = Counter(row['event'] for row in gateway)
    fault_count = Counter(row['fault'] for row in first.values())
    fault_counts = {name: {'assigned': count, 'durable_receipts': sum(
        first[operation_id]['fault'] == name for operation_id in receipts), 'pending_observed': sum(
        first[row['id']]['fault'] == name for row in pending.values())} for name, count in sorted(fault_count.items())}
    independent = sum(r['scope'] == 'independent' for r in first.values())
    require(independent == receipt_counts['independent'], 'Unaffected legitimate operations failed')
    require(all(receiver_counts[event] > 0 for event in ('precommit_fenced', 'ack_suppressed', 'query_reply_withheld')), 'Missing real fault evidence')
    require(gateway_counts['duplicate_returned_cached_status'] > 0 and
            any(r['action'] == 'concurrent_duplicate' for r in client), 'Duplicate replays were not exercised')
    require(receipt_counts['old_committed_during_write_wait'] > 0 and len(denied) > 0, 'No delivery actually overlapped the revocation wait')
    recovery = distribution([clock(row) - clock(pending[key]) for key, row in resolutions.items()])
    return {
        'operations': len(first), 'durable_receipts': len(receipts), 'post_revocation_old_epoch_new_receipts': 0,
        'duplicate_durable_receipts': 0, 'receipt_digest_mismatches': 0,
        'currently_unresolved_operations': len(set(first) - set(settled)),
        'independent_submitted': independent, 'independent_delivered': receipt_counts['independent'],
        'old_epoch_prepublication_delivered': receipt_counts['withdrawn'],
        'old_committed_during_revoke_write_wait': receipt_counts['old_committed_during_write_wait'],
        'old_scope_denied_attempts': len(denied), 'durable_attempt_fences': len(fences),
        'authorized_retries_after_fence': sum(attempt > 1 for _, attempt in auth),
        'independent_recovery_timing': recovery, 'actual_receiver_events': dict(receiver_counts),
        'gateway_events': dict(gateway_counts), 'faults': fault_counts,
    }


def sha256_text(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    directory = parser.parse_args().directory
    result = audit(directory)
    (directory / '竞态账本独立核验.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
