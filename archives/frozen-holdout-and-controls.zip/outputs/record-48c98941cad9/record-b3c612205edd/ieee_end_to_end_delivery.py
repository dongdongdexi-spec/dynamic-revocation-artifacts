"""Benchmark synthetic delivery and revocation through an actual local recipient."""

import argparse
import csv
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import socket
import socketserver
import sqlite3
from statistics import median, quantiles
import threading
import time

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


SCALES = (1, 6, 16, 32, 64)
SCENARIOS = ('authorized', 'queued', 'late', 'partial', 'queued', 'late', 'partial',
             'queued', 'late', 'partial', 'late_ack', 'restart')
RECIPIENT = 'synthetic-trusted-receiver'
NOW = time.perf_counter_ns
WAIT = 40


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def read_frame(stream):
    row = stream.readline(100_000)
    if not row.endswith(b'\n'):
        raise ValueError('Incomplete message')
    return json.loads(row)


def write_frame(stream, value):
    stream.write(encode(value) + b'\n')
    stream.flush()


def request(address, value):
    with socket.create_connection(address, timeout=WAIT) as conn:
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        with conn.makefile('rwb') as stream:
            write_frame(stream, value)
            return read_frame(stream)


def proof(body):
    return hashlib.sha256(body.encode('utf-8')).hexdigest()


def aad(job):
    return encode([job['id'], job['scope'], job['epoch'], job['recipient']])


def connect_db(path):
    connection = sqlite3.connect(path)
    connection.execute('PRAGMA synchronous=FULL')
    return connection


class ReceiverHandler(socketserver.StreamRequestHandler):
    def handle(self):
        packet = read_frame(self.rfile)
        if packet['kind'] == 'stop':
            write_frame(self.wfile, {'stopped': True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        received = NOW()
        item = packet['item']
        if item['recipient'] != RECIPIENT or proof(item['body']) != item['sha256']:
            raise ValueError('Receiver could not verify its assigned payload')
        db = connect_db(self.server.database)
        try:
            with db:
                db.execute('INSERT INTO receipts VALUES (?, ?, ?, ?, ?, ?, ?)',
                           (item['id'], item['epoch'], item['scope'], item['recipient'],
                            item['body'], item['sha256'], received))
        finally:
            db.close()
        write_frame(self.wfile, {'received_ns': received, 'committed_ns': NOW(), 'sha256': item['sha256']})


def receiver_main(database, control):
    db = connect_db(database)
    try:
        with db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('CREATE TABLE receipts (id TEXT PRIMARY KEY, epoch INT, scope TEXT, recipient TEXT, '
                       'body TEXT, sha256 TEXT, received_ns INT)')
    finally:
        db.close()
    with socketserver.TCPServer(('127.0.0.1', 0), ReceiverHandler) as server:
        server.database = database
        control.send((server.server_address, os.getpid()))
        control.close()
        server.serve_forever(poll_interval=.02)


class Gateway:
    def __init__(self, recipient):
        self.recipient = recipient
        self.lock = threading.Lock()
        self.condition = threading.Condition()
        self.resume_ack = threading.Event()
        self.epoch = 0
        self.jobs = {}
        self.deliveries = []

    def setup(self, source, count, trial, scenario):
        self.resume_ack.clear()
        self.epoch = source
        self.scenario = scenario
        self.deliveries = []
        self.keys = {name: AESGCM.generate_key(bit_length=256) for name in ('protected', 'independent')}
        self.jobs = {}
        for worker in range(count):
            for scope, key in self.keys.items():
                job_id = f'{count:02d}-{trial:02d}-{worker:02d}-{scope}'
                job = {'id': job_id, 'epoch': source, 'scope': scope, 'recipient': RECIPIENT}
                body = f'SYNTHETIC:{scope}:{job_id}:' + os.urandom(96).hex()
                self.jobs[job_id] = proof(body)
                nonce = os.urandom(12)
                encrypted = AESGCM(key).encrypt(nonce, body.encode('utf-8'), aad(job))
                yield job | {'nonce': nonce.hex(), 'ciphertext': encrypted.hex()}

    def revoke(self):
        called = NOW()
        with self.lock:
            acquired = NOW()
            del self.keys['protected']
            published = NOW()
        return called, acquired, published, NOW()

    def process(self, job):
        check_started = NOW()
        receiver = None
        decrypt_ns = None
        with self.lock:
            acquired = NOW()
            key = self.keys.get(job['scope']) if job['epoch'] == self.epoch else None
            allowed = key is not None and job['recipient'] == RECIPIENT
            checked = NOW()
            if allowed:
                body = AESGCM(key).decrypt(bytes.fromhex(job['nonce']), bytes.fromhex(job['ciphertext']), aad(job)).decode()
                decrypt_done = NOW()
                decrypt_ns = decrypt_done - checked
                assert self.jobs[job['id']] == proof(body)
                receiver = request(self.recipient, {'kind': 'receive', 'item': {
                    'id': job['id'], 'body': body, 'sha256': self.jobs[job['id']], 'epoch': job['epoch'],
                    'scope': job['scope'], 'recipient': job['recipient'],
                }})
                assert receiver['sha256'] == self.jobs[job['id']]
        if allowed and job['scope'] == 'protected' and self.scenario == 'late_ack':
            with self.condition:
                self.deliveries.append(receiver['committed_ns'])
                self.condition.notify_all()
            if not self.resume_ack.wait(WAIT):
                raise TimeoutError('Client acknowledgment release did not arrive')
        ack_ready = NOW()
        return {'id': job['id'], 'allowed': int(allowed), 'decision_ns': checked,
                'lock_wait_ns': acquired - check_started, 'check_ns': checked - acquired,
                'check_with_wait_ns': checked - check_started, 'decrypt_ns': decrypt_ns,
                'receiver_received_ns': None if receiver is None else receiver['received_ns'],
                'receiver_committed_ns': None if receiver is None else receiver['committed_ns'],
                'ack_ready_ns': ack_ready}


class GatewayHandler(socketserver.StreamRequestHandler):
    def handle(self):
        write_frame(self.wfile, self.server.gateway.process(read_frame(self.rfile)))


class GatewayServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    request_queue_size = 128


def worker_loop(address, control, release, pending):
    staged = []
    ready_ns = None
    while True:
        command, data = control.recv()
        if command == 'stop':
            control.close()
            return
        if command == 'stage':
            scenario, staged = data
            ready_ns = NOW()
            if scenario == 'restart':
                with pending.open('w', encoding='utf-8') as stream:
                    json.dump(staged, stream)
                    stream.flush()
                    os.fsync(stream.fileno())
                ready_ns = NOW()
            control.send((os.getpid(), ready_ns))
            continue
        if command == 'resume':
            with pending.open(encoding='utf-8') as stream:
                staged = json.load(stream)
            ready_ns = NOW()
        if not release.wait(WAIT):
            raise TimeoutError('Worker dispatch release did not arrive')
        if data == 'late':
            ready_ns = NOW()
        results = []
        for job in staged:
            sent = NOW()
            result = request(address, job)
            arrived = NOW()
            results.append(result | {'scope': job['scope'], 'dispatched_ns': sent,
                                     'worker_ack_ns': arrived, 'e2e_ns': arrived - sent})
        control.send((os.getpid(), ready_ns, results))


def start_workers(ctx, address, release, directory, count):
    workers = []
    for index in range(count):
        parent, child = ctx.Pipe()
        pending = directory / f'pending-{index:02d}.json'
        process = ctx.Process(target=worker_loop, args=(address, child, release, pending))
        process.start()
        child.close()
        workers.append((parent, process))
    return workers


def from_worker(control):
    if not control.poll(WAIT):
        raise TimeoutError('Worker did not report completion')
    return control.recv()


def stop_workers(workers):
    for pipe, process in workers:
        if process.is_alive():
            pipe.send(('stop', None))
        pipe.close()
    for _, process in workers:
        process.join(WAIT)
        if process.is_alive():
            process.terminate()
            process.join()
        if process.exitcode != 0:
            raise RuntimeError(f'Downstream {process.pid} exited {process.exitcode}')


def run_scale(ctx, server, count, rounds, directory):
    release = ctx.Event()
    print(f'{count} connected downstream workers', flush=True)
    workers = start_workers(ctx, server.server_address, release, directory, count)
    gateway = server.gateway
    try:
        for trial, scenario in enumerate(SCENARIOS * rounds, start=1):
            release.clear()
            source = count * 1_000 + trial
            jobs = list(gateway.setup(source, count, trial, scenario))
            for index, (pipe, _) in enumerate(workers):
                pipe.send(('stage', (scenario, jobs[2 * index:2 * index + 2])))
            staged = [from_worker(pipe) for pipe, _ in workers]
            event = (None,) * 4
            if scenario == 'restart':
                stop_workers(workers)
                workers = []
                event = gateway.revoke()
                workers = start_workers(ctx, server.server_address, release, directory, count)
            elif scenario not in {'authorized', 'late_ack'}:
                event = gateway.revoke()
            for pipe, _ in workers:
                pipe.send(('resume' if scenario == 'restart' else 'send', scenario))
            release.set()
            if scenario == 'late_ack':
                with gateway.condition:
                    if not gateway.condition.wait_for(lambda: len(gateway.deliveries) == count, timeout=WAIT):
                        raise TimeoutError('Pre-revocation recipient commits did not finish')
                event = gateway.revoke()
                gateway.resume_ack.set()
            completed = [from_worker(pipe) for pipe, _ in workers]
            assert len({row[0] for row in completed}) == count
            called, acquired, revoke, returned = event
            for worker, ((stage_pid, stage_ns), (pid, ready_ns, records)) in enumerate(zip(staged, completed, strict=True)):
                for row in records:
                    yield {'workers': count, 'round': trial, 'scenario': scenario, 'worker': worker,
                           'queued_pid': stage_pid, 'dispatch_pid': pid, 'stage_ns': stage_ns, 'result_ready_ns': ready_ns,
                           'revoke_called_ns': called, 'revoke_lock_acquired_ns': acquired, 'revoke_ns': revoke,
                           'revoke_returned_ns': returned, 'slot_update_ns': None if revoke is None else revoke - acquired,
                           'expected_body_sha256': gateway.jobs[row['id']], **row}
    finally:
        stop_workers(workers)


def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=tuple(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def audit(rows, database):
    db = connect_db(database)
    try:
        receipts = {item[0]: item for item in db.execute('SELECT * FROM receipts')}
    finally:
        db.close()
    assert len({r['id'] for r in rows}) == len(rows)
    for row in rows:
        protected = row['scope'] == 'protected'
        revoke = row['revoke_ns']
        case = row['scenario']
        allowed = not protected or case in {'authorized', 'late_ack'}
        assert row['dispatched_ns'] <= row['decision_ns'] <= row['ack_ready_ns'] <= row['worker_ack_ns']
        assert bool(row['allowed']) == allowed and (row['id'] in receipts) == allowed
        if allowed:
            receipt = receipts[row['id']]
            assert receipt[2:4] == (row['scope'], RECIPIENT)
            assert proof(receipt[4]) == receipt[5] == row['expected_body_sha256']
            assert row['decision_ns'] <= receipt[6] == row['receiver_received_ns']
            assert receipt[6] <= row['receiver_committed_ns'] <= row['ack_ready_ns']
            assert row['decrypt_ns'] is not None
        else:
            assert row['receiver_received_ns'] is None and row['decrypt_ns'] is None
            assert row['decision_ns'] >= revoke
        if case == 'restart':
            assert row['queued_pid'] != row['dispatch_pid'] and row['stage_ns'] <= revoke < row['result_ready_ns']
        if case == 'late':
            assert row['stage_ns'] <= revoke < row['result_ready_ns']
        if case == 'late_ack' and protected:
            assert row['receiver_committed_ns'] < revoke < row['worker_ack_ns']
        if case in {'queued', 'partial'}:
            assert row['stage_ns'] <= revoke < row['dispatched_ns']
    return len(receipts)


def stats(values):
    if len(values) == 1:
        return {'p50_ns': values[0], 'p95_ns': values[0], 'n': 1}
    return {'p50_ns': median(values), 'p95_ns': quantiles(values, n=100, method='inclusive')[94], 'n': len(values)}


def summarize(rows):
    result = {}
    for count in sorted({row['workers'] for row in rows}):
        cell = [r for r in rows if r['workers'] == count]
        delivered = [r for r in cell if r['allowed']]
        protected = [r for r in cell if r['scope'] == 'protected']
        slot_times = [r['slot_update_ns'] for r in cell if r['slot_update_ns'] is not None and
                      r['worker'] == 0 and r['scope'] == 'protected']
        counts = {s: {k: sum(pred(r) for r in cell if r['scenario'] == s) for k, pred in (
            ('protected_delivered',lambda r:r['scope']=='protected' and r['allowed']),
            ('protected_denied',lambda r:r['scope']=='protected' and not r['allowed']),
            ('independent_delivered',lambda r:r['scope']=='independent' and r['allowed']),
        )} for s in sorted({r['scenario'] for r in cell})}
        standard = [r for r in delivered if r['scenario'] not in {'late_ack', 'restart'}]
        result[count] = {'counts': counts, 'slot_update': stats(slot_times), 'check': stats([r['check_ns'] for r in cell]),
                         'check_with_wait': stats([r['check_with_wait_ns'] for r in cell]),
                         'decrypt': stats([r['decrypt_ns'] for r in delivered]),
                         'delivered_e2e_without_held_ack_or_restart': stats([r['e2e_ns'] for r in standard]),
                         'delivered_e2e_all': stats([r['e2e_ns'] for r in delivered]),
                         'denied_e2e': stats([r['e2e_ns'] for r in protected if not r['allowed']])}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workers', nargs='+', type=int, default=SCALES)
    parser.add_argument('--cycles', type=int, default=1, help='12 rounds per cycle')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    database = args.out / '实收账本.sqlite'
    if database.exists():
        parser.error('Choose a new output directory for each run')
    ctx = mp.get_context('spawn')
    parent, child = ctx.Pipe(duplex=False)
    receiver = ctx.Process(target=receiver_main, args=(database, child))
    receiver.start()
    child.close()
    try:
        address, pid = from_worker(parent)
        with GatewayServer(('127.0.0.1', 0), GatewayHandler) as server:
            server.gateway = Gateway(address)
            thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
            thread.start()
            rows = []
            try:
                for count in args.workers:
                    directory = args.out / f'待办-{count:02d}'
                    directory.mkdir()
                    rows.extend(run_scale(ctx, server, count, args.cycles, directory))
            finally:
                server.shutdown()
                thread.join()
        request(address, {'kind': 'stop'})
        receiver.join(WAIT)
        if receiver.exitcode != 0:
            raise RuntimeError(f'Receiver exit code {receiver.exitcode}')
        deliveries = audit(rows, database)
        write_csv(args.out / '逐提交轨迹.csv', rows)
        result = {'recipient_process': pid, 'gateway_process': os.getpid(), 'workers': args.workers,
                  'acls': 'one central gateway, one independent trusted receiver, no direct worker-to-receiver calls',
                  'record_count': len(rows), 'receipts': deliveries, 'scales': summarize(rows)}
        (args.out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f'{len(rows)} proposals, {deliveries} independently checked body receipts', flush=True)
    finally:
        if receiver.is_alive():
            receiver.terminate()
            receiver.join()
        parent.close()


if __name__ == '__main__':
    main()
