"""Generate the manuscript-ready tables and plot from the delivery benchmark."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sqlite3


def pair(cell, key, unit):
    numerical = cell[key]
    return ' / '.join(f'{numerical[p] / unit:.3f}' for p in ('p50_ns', 'p95_ns'))


def plot(out, sizes, result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    palette = ['#076782', '#27553f', '#c07737', '#5b4970']
    fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.25), layout='constrained')
    metrics = [(['slot_update', 'check', 'decrypt'], ['Epoch slot update', 'Authorization in lock', 'Body decrypt and decoding'],
                'Central operations', 'Latency (µs)', 1e3),
               (['check_with_wait', 'delivered_e2e_without_held_ack_or_restart', 'denied_e2e'],
                ['Authorization with lock wait', 'Body delivery and acknowledgment', 'Denied request and acknowledgment'],
                'Request paths', 'Latency (ms)', 1e6)]
    for ax, (keys, labels, title, unit, divisor) in zip(axes, metrics, strict=True):
        for key, label, color in zip(keys, labels, palette):
            mid = [result[str(size)][key]['p50_ns'] / divisor for size in sizes]
            high = [result[str(size)][key]['p95_ns'] / divisor for size in sizes]
            ax.plot(sizes, mid, '-o', label=label, color=color, lw=1.9, markersize=4)
            ax.plot(sizes, high, ':', color=color, lw=1.2)
        ax.set_xscale('log', base=2)
        ax.set_xticks(sizes, sizes)
        ax.set(title=title, xlabel='Independent downstream processes', ylabel=unit, ylim=(0, None))
        ax.spines[['right', 'top']].set_visible(False)
        ax.grid(axis='y', color='#dce3e7', lw=.8)
        ax.legend(fontsize=8, loc='upper left')
    fig.suptitle('Revocation through a local recipient · p50 solid · p95 dotted', fontsize=13)
    fig.savefig(out / '端到端并发曲线.svg')
    fig.savefig(out / '端到端并发曲线.png', dpi=190)


def generate_report(package):
    record = json.loads((package / 'result.json').read_text(encoding='utf-8'))
    sizes, result = record['workers'], record['scales']
    cases = {'authorized': '保留授权', 'queued': '排队后撤权', 'late': '回传晚于撤权', 'partial': '部分撤权',
             'late_ack': '已提交后撤权，回执延后', 'restart': '撤权时下游离线，重启后续办'}
    table = {name: {value: sum(result[str(size)]['counts'][name][value] for size in sizes)
                    for value in ('protected_delivered', 'protected_denied', 'independent_delivered')} for name in cases}
    destination = package / '端到端并发实测.md'
    blocked = sum(row['protected_denied'] for row in table.values())
    independent = sum(row['independent_delivered'] for row in table.values())
    total_expected = table['authorized']['protected_delivered'] + table['late_ack']['protected_delivered'] + independent
    assert total_expected == record['receipts'] and blocked + total_expected == record['record_count']
    with sqlite3.connect(package / '实收账本.sqlite') as db:
        verified = db.execute('SELECT scope, COUNT(*) FROM receipts GROUP BY scope').fetchall()
        assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        assert dict(verified) == {'independent': independent, 'protected': total_expected - independent}
        receipts = dict(db.execute('SELECT id, body FROM receipts'))
    with (package / '逐提交轨迹.csv').open(encoding='utf-8', newline='') as stream:
        traces = list(csv.DictReader(stream))
    assert len(traces) == record['record_count'] == len({row['id'] for row in traces})
    for row in traces:
        delivered = row['id'] in receipts
        assert delivered == (row['allowed'] == '1')
        if delivered:
            digest = hashlib.sha256(receipts[row['id']].encode()).hexdigest()
            assert digest == row['expected_body_sha256']
        if row['scope'] == 'protected' and delivered and row['revoke_ns']:
            assert int(row['receiver_committed_ns']) < int(row['revoke_ns']) < int(row['worker_ack_ns'])
    formatted = ['# 独立进程并发下的正文交付与动态撤权', '',
                 f'测试规模为 {"、".join(map(str, sizes))} 个独立下游。每档 12 轮，共 {12 * len(sizes)} 轮。'
                 f'共 {record["record_count"]:,} 次提交，独立收件进程在 SQLite 账本实收并校验 {record["receipts"]:,} 份合成正文。', '',
                 f'所有 {blocked:,} 次撤权生效后尝试提交的受限正文均被网关拒绝，实际收件账本中为 0 条。'
                 f'{independent:,}/{independent:,} 项保留授权的独立交付均正确实收。'
                 f'{table["late_ack"]["protected_delivered"]} 份受限正文在撤权前提交成功，撤权后下游才收到确认回执。', '',
                 '| 受控场景 | 受限实收（撤权前或保留授权） | 受限拒绝 | 独立获准实收 |',
                 '|---|---:|---:|---:|']
    for key, name in cases.items():
        counts = table[key]
        formatted.append(f'| {name} | {counts["protected_delivered"]} | {counts["protected_denied"]} | {counts["independent_delivered"]} |')
    formatted += ['', '| 下游进程 | 中央旧槽失效（µs） | 锁内核权（µs） | 核权含锁等待（ms） | 解密与正文解析（µs） | 正常获准交付往返（ms） | 拒绝往返（ms） |',
                  '|---:|---:|---:|---:|---:|---:|---:|']
    for size in sizes:
        cell = result[str(size)]
        specs = [('slot_update',1e3), ('check',1e3), ('check_with_wait',1e6), ('decrypt',1e3),
                 ('delivered_e2e_without_held_ack_or_restart',1e6), ('denied_e2e',1e6)]
        formatted.append(f'| {size} | ' + ' | '.join(pair(cell, field, unit) for field, unit in specs) + ' |')
    formatted += [
        '', '每格为 p50 / p95。锁内核权与含锁等待的核权同时报告。网关等待包含前一条交付持锁完成收件提交造成的排队。'
        '解密计时包括在锁内进行的 AES-GCM 解密、十六进制解码和 UTF-8 解码。上表的正常获准往返排除人为延迟回执轮和重启轮，`result.json` 包含全部样本的分位数。', '',
        '![独立进程、真实正文收件的并发曲线](端到端并发曲线.png)', '',
        '## 执行和判定', '',
        '每个下游持有自己 PID 和 TCP 连接，运行待办并向中央网关提交已加密的合成正文。独立收件进程通过另一个本机 TCP 连接接收正文，并保存正文与哈希。'
        '网关持同一把锁完成当前旧槽核验、解密及等待收件端 SQLite 提交确认，撤权通过这把锁发布。撤权和收件提交因此在此实现中互斥。'
        '撤权线性化点是锁内删除旧槽后记录发布的时点。收件确认用收件进程的同机单调时钟记录，SQLite 设为 WAL 与 `synchronous=FULL`。', '',
        '每档按固定顺序完成 1 轮保权、排队后撤权／迟到回传／部分撤权各 3 轮、1 轮主动延迟回执和 1 轮重启。部分撤权使用同一工作单的两条独立提交；'
        '续办策略的相对效果在组件消融中单独测。重启轮先把待办写盘，再让所有初始下游退出。撤权后以新 PID 加载同一文件。'
        '迟到回传轮在撤权后才向网关提交可用结果。延迟回执轮等待所有受限正文完成收件端提交后才撤权，再释放下游确认回执。', '',
        '计时使用 `perf_counter_ns`。网关会话与收件服务在实验前启动。下游冷启动及重启等待均在每条网络请求计时之前；每条测量请求仍包括 TCP 建连。'
        '本实验固定为同机回环、合成载荷及受控的正常收件路径，网关与收件端都受信任。测试不涵盖收件端不可用、提交确认丢失、跨机或可独立缓存密钥的下游。'
        '历史 2,048 持有者进程内曲线使用原来的本地测量文件，单独归档。', '',
        '## 证据文件与复测', '',
        '- `逐提交轨迹.csv` 逐项记录待办、撤权、网关决定、网关核权、解密、收件提交、下游回执、前后 PID 及正文哈希。',
        '- `实收账本.sqlite` 保存独立收件端的正文、接收时间和哈希。受限正文全部为合成字段。',
        '- `result.json` 保存按场景、并发档位分组的结果与全部分段计时。',
        '- 使用 `python ieee_end_to_end_delivery.py --out 新目录 --workers 1 6 16 32 64` 复跑，依赖 `cryptography`。',
        '- 使用 `python ieee_end_to_end_report.py 新目录` 核验正文哈希、生成报告和图，依赖 `matplotlib`。', '',
    ]
    destination.write_text('\n'.join(formatted), encoding='utf-8')
    plot(package, sizes, result)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('directory', type=Path)
    generate_report(cli.parse_args().directory)


if __name__ == '__main__':
    main()
