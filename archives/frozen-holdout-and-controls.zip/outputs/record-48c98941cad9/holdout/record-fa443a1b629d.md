# 独立留出题库

24 道题覆盖金融、医疗质量统计、法律、员工福利和科研五个领域。四种撤权时序各 6 题，每个领域都包含四种时序。公开资料只通过短事实摘要、量化索引和业务结构进入题目。所有工单、标识、待办、收件台、受限字段以及答题政策均由本实验合成。

六类下游分别承担公开资料核验、修订账本统计、权限与接收人校验、交付编排、行政排期、受限档案保管。四轮压缩快照预先按可复现规则生成，逐轮删去全文与过时行、保留账本谱系、路由与排期条件。这些快照为共享输入，最终字段值通过角色材料和规则推导。

每题完整文件含评分字段。模型运行时按实验协议只获得任务材料、指定角色或摘要、当前授权和当阶段的收件事实。合成的当期受限字段在角色材料里只有保管岗 F 一处。

## 公共材料索引

- `ADBE24` Item 8, Consolidated Statements of Income。FY2024 收入 21,505 百万美元，订阅收入 20,521 百万美元。 [Adobe FY 2024 Form 10-K](https://www.sec.gov/Archives/edgar/data/796343/000079634325000004/adbe-20241129.htm)
- `COST24` Consolidated Statements of Income。FY2024 会员费 4,828 百万美元，总收入 254,453 百万美元。 [Costco FY 2024 Form 10-K](https://www.sec.gov/Archives/edgar/data/909832/000090983224000049/cost-20240901.htm)
- `COST25` Consolidated Statements of Income。FY2025 会员费 5,323 百万美元，总收入 275,235 百万美元。 [Costco FY 2025 Form 10-K](https://www.sec.gov/Archives/edgar/data/909832/000090983225000101/cost-20250831.htm)
- `INTC24` Operating segment results / consolidated statements。FY2024 合并收入 53,101 百万美元，报告区分内部交易与合并数字。 [Intel FY 2024 Form 10-K](https://www.sec.gov/Archives/edgar/data/50863/000005086325000009/intc-20241228.htm)
- `HCAHPS` About the survey / reporting。医院患者体验调查于 2006 年全国实施，从 2008 年开始公开报告。 [CMS Hospital CAHPS](https://www.cms.gov/data-research/research/consumer-assessment-healthcare-providers-systems/hospital-cahps-hcahps)
- `STAR` Eligibility for HCAHPS Star Ratings。该说明书指出 HCAHPS 星级评分要求 12 个月报告期内至少 100 份调查并符合公开报告资格。 [CMS Hospital Compare Star Ratings Fact Sheet](https://www.cms.gov/newsroom/fact-sheets/hospital-compare-star-ratings-fact-sheet)
- `OQR` Program overview, data refresh。该 CMS 项目覆盖门诊医疗质量，Compare 数据按季度刷新，每年四次刷新是本题索引口径。 [CMS Hospital Outpatient Quality Reporting Program](https://www.cms.gov/medicare/quality/initiatives/hospital-quality-initiative/outpatient-reporting-program)
- `AI09` Regulation (EU) 2024/1689, Article 9。第 9 条将高风险 AI 的风险管理设置为全生命周期内的持续迭代过程。 [EU AI Act, official original text](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=OJ%3AL_202401689)
- `AI12` Regulation (EU) 2024/1689, Article 12。第 12 条涉及高风险 AI 系统生命周期内的自动事件记录。 [EU AI Act, official original text](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=OJ%3AL_202401689)
- `DA04` Regulation (EU) 2023/2854, Article 4。第 4 条涉及用户访问、使用互联产品及相关服务数据，以及数据持有者提供数据的义务。 [EU Data Act, official text](https://eur-lex.europa.eu/eli/reg/2023/2854/oj/eng/pdf)
- `DA05` Regulation (EU) 2023/2854, Article 5。第 5 条涉及用户将数据分享给第三方。 [EU Data Act, official text](https://eur-lex.europa.eu/eli/reg/2023/2854/oj/eng/pdf)
- `BLS24` Highlights / Selected paid leave benefits。2024 年 3 月私营部门带薪病假可及率 79%，州与地方政府可及率 92%。 [BLS Employee Benefits in the United States, March 2024](https://www.bls.gov/news.release/archives/ebs2_09192024.htm)
- `BLS25` Table 2, Medical care benefits。2025 年 3 月私营部门医疗福利可及率 72%，参与率 45%，两者分列。 [BLS Employee Benefits in the United States, March 2025](https://www.bls.gov/news.release/archives/ebs2_09252025.htm)
- `BLS25S` Release summary。2025 年私营部门雇员的带薪病假可及率整体为 80%。 [BLS The Economics Daily, 2025 paid sick leave](https://www.bls.gov/opub/ted/2026/paid-sick-leave-was-available-to-80-percent-of-private-industry-workers-in-2025.htm)
- `HERD23` Table 1, Higher education R&D by source of funds。FY2023 高等教育研发支出 108,841 百万美元，其中联邦资金 59,679 百万美元。 [NSF NCSES, FY 2023 HERD survey](https://ncses.nsf.gov/pubs/nsf25313/table/1)
- `NSB25` Academic R&D funding。2023 年联邦资金约占美国高校研发支出的 55%。 [NSB Science and Engineering Indicators NSB-2025-7](https://ncses.nsf.gov/pubs/nsb20257/assets/nsb20257.pdf)
- `RMF` Part 2, AI RMF Core。AI RMF Core 有四项功能 Govern、Map、Measure 和 Manage。 [NIST AI Risk Management Framework 1.0](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf)
